# Treehouse Connect [DEV]

Native Android development project, version 0.1.0. App ID: dev.treehouse.connect.

## Included features

* Dashboard with greeting, unread count, theme summary, and quick actions.
* Editable local profile with display name and bio, persisted across restarts.
* System, light, and dark themes, with a saved preference.
* Settings for notifications, appearance, Android notification controls, and confirmed local-data reset.
* Persistent notification inbox with read/unread state, mark-all-read, and confirmed clear.
* Working local Android test notifications with Android 13+ permission handling and tap-to-open inbox.
* Custom tree launcher icon and green, rounded-card interface.

This is an offline development edition. It has no login, cloud profiles, server connection, analytics, or remote push notification service. The project does not request Internet access. Profiles are not shared with other devices. Local backup is disabled. Inbox retains the latest 100 updates.

## Build an installable debug APK

This deliverable contains source code, not an APK. The authoring environment had Java but no Android SDK or Gradle, so compilation, emulator tests, and device tests were not possible.

1. Extract this archive and open its TreehouseConnect folder in Android Studio.
2. Use JDK 17. Install Android SDK Platform 35 and allow Android Studio to install the required SDK build tools.
3. Use Gradle 8.9 with Android Gradle Plugin 8.7.3. This source archive does not contain a Gradle wrapper binary. If Studio requests a wrapper, install Gradle 8.9 and run `gradle wrapper --gradle-version 8.9` from this folder; then sync the project in Studio.
4. Build the debug APK using Studio's APK build action, or run `gradle :app:assembleDebug` with Gradle 8.9 and ANDROID_HOME configured. After generating the wrapper, `./gradlew :app:assembleDebug` is also available.
5. The debug-signed installable APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to an Android device (Android 8.0 or newer), permit installation from the chosen file app if prompted, and install. With Android platform-tools, use `adb install -r app/build/outputs/apk/debug/app-debug.apk`.

Debug APKs use an automatically generated local debug key. Future updates must be signed with the same key to install over an existing app. Production distribution requires a release signing key.

## Manual acceptance checklist

- Open the dashboard and navigate all four tabs.
- Save a name and bio; force-close and reopen; confirm both persist.
- Reject an empty name; validate the 60-character name and 500-character bio limits.
- Switch among Light, Dark, and System; confirm the selected theme persists after reopening.
- Send a test notification on Android 13+: allow permission; check the tray and inbox.
- Tap the tray notification with the app running and with the app closed; confirm Inbox opens.
- Deny permission: confirm the local inbox still receives the test update and a status message explains that Android notifications are blocked.
- Disable the in-app notification setting: confirm tests are blocked and existing tray notification is cleared.
- Mark updates as read, restart, and confirm read status persists.
- Cancel and confirm inbox clear and local reset separately.
- Check portrait, landscape, a small screen, large text, and dark mode on a device or emulator.

## Implementation

Java Activity and native Android widgets; no third-party runtime dependencies. SharedPreferences stores profile, settings, and inbox. NotificationChannel and NotificationManager provide local test alerts. Minimum SDK 26; compile SDK 35; target SDK 34.

## Verification performed here

Manifest and resource XML parsed successfully. Archive integrity and expected project structure checked. No Android compilation or runtime verification was performed; complete the checklist above after building.
