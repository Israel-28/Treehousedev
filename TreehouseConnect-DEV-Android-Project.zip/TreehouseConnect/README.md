# Treehouse Connect [DEV] 0.4.0

A utility dashboard for your treehouse, with three equipment zones: Level 1 lower lounge, Level 2 kitchen deck, and Level 3 chair area.

## Features

- Redesigned forest-and-cream interface with custom navigation icons, power overview, paired energy cards, and concise settings rows.

- Animated screen entrances and button press feedback, with per-account Reduce motion and system animation settings respected.
- Multiple local accounts with independent saved data, switching, renaming, and confirmed deletion. These are local profiles, not password-protected online accounts. Anyone using the app can switch. Cloud authentication and sync are not provided.
- Supplies / kitchen inventory with quantities and level locations.
- Maintenance checklist with edit, remove, completion state, and notes. Target dates are notes, not scheduled reminders.

- Power station inputs: capacity in Wh, battery %, input charging watts, efficiency, and electricity rate.
- Equipment inventory: edit wattage, hours/day, zone, and inclusion in the active-load estimate.
- Estimated daily Wh/kWh and cost, runtime, and time to charge. These assume constant load and charging input; charging taper is not modeled.
- Energy journal labeled as manual meter readings or estimates.
- Town-based outdoor weather using Open-Meteo, including temperature, feels-like, humidity, and wind. Town selection handles ambiguous search results. Cached weather shows fetch time and model timestamp.
- Manual treehouse thermometer journal by level.
- Phone internet connectivity and metered status, Wi-Fi settings shortcut, provider and manual speed-test notes.
- Saved themes, local profile, local notification test and inbox, and confirmed reset / history deletion.

The app does not connect to a power station, control lights, read a remote thermometer, measure your treehouse internet from elsewhere, or run a speed test. All hardware readings are manual. No sample equipment or fake sensor values are preloaded. The 85% efficiency and $0.15/kWh rate are editable starting assumptions. Active load toggles affect the current load estimate; daily energy uses planned wattage × hours/day for every saved device.

## Weather and privacy

Weather requests send the town you enter and selected town coordinates to Open-Meteo via HTTPS. Weather refresh is manual; no GPS or background collection. Outdoor weather is weather-model data, not an indoor reading. Weather attribution: https://open-meteo.com/ . Open-Meteo API terms apply to future use / distribution; this is a personal development build. All other entries stay in app-private local storage. No passwords should be entered in connection notes. Android backup is disabled.

## Build

JDK 17, Android SDK 35, Gradle 8.9, Android Gradle Plugin 8.7.3. Minimum Android 8.0. The source archive omits wrapper binaries; install Gradle 8.9 or generate a wrapper with `gradle wrapper --gradle-version 8.9`.

Run `gradle :app:assembleDebug` from this directory. APK: `app/build/outputs/apk/debug/app-debug.apk`. The repository workflow extracts this source archive, runs standalone power calculation checks, and builds a debug APK.

Run standalone calculation checks with:

```
javac -d test-build app/src/main/java/dev/treehouse/connect/PowerMath.java tests/PowerMathTest.java
java -cp test-build PowerMathTest
```

## Manual device checks

1. Add a 20 W device for 5 h/day. Verify 100 Wh/day; at $0.15/kWh, cost rounds to $0.02.
2. Enter 500 Wh capacity, 50% battery, 80% efficiency; with 100 W active load and 0 W input, verify 2.0 h runtime. At 50 W input, verify 4.0 h.
3. Set 150 W input with 50 W active load; verify charging time to full of 3.1 h. At 100% battery, verify full status.
4. Reject blank / malformed numbers, negative wattage, hours over 24, battery over 100, and zero capacity or efficiency.
5. Edit / remove equipment, toggle active load, log energy and temperatures, restart the app, and check persistence. Cancel deletion before confirming it.
6. Refresh weather with a town, choose an ambiguous match, try a nonexistent town and an offline connection. Confirm cached data is retained with timestamps and an error.
7. Check Wi-Fi and cellular connection states and system Wi-Fi settings. Confirm speed fields are explicitly manual.
8. Test notification permissions and notification tap with app open and closed.
9. Switch light / dark / system themes; check dialogs, rotation, large text, and a small phone.
10. Verify upgrade installs over 0.1.0 when signed with the same debug key. The CI caches its development key; if that cache is lost, future builds may require uninstalling the old app, which removes local data.

Compilation and calculation test results are reported separately from physical device tests. This version has not been exercised on an Android phone here.

## Account and animation checks

Create a second account, add different equipment/supplies/tasks, and switch back and forth to confirm isolation. Restart and confirm the active account persists. Rename accounts, reject duplicates, cancel deletion, then delete one account and verify the other data remains. Existing v0.2 data appears in Main account. Old Upper deck entries migrate to Level 2 kitchen deck; Lower lounge to Level 1. Test reduce-motion and Android animation-scale zero. Weather results from a prior account must not save into a newly selected account.
