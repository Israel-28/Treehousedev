import dev.treehouse.connect.PowerMath;
public class PowerMathTest {
    private static void close(double actual,double expected){if(Math.abs(actual-expected)>0.000001)throw new AssertionError(actual+" != "+expected);}
    public static void main(String[] args){
        close(PowerMath.energyWh(20,5),100);
        close(PowerMath.availableWh(500,50,80),200);
        close(PowerMath.runtimeHours(500,50,80,100,0),2);
        close(PowerMath.runtimeHours(500,50,80,100,50),4);
        close(PowerMath.runtimeHours(500,0,80,100,0),0);
        if(!Double.isInfinite(PowerMath.runtimeHours(500,50,80,100,100)))throw new AssertionError("Balanced input should have no drain");
        if(!Double.isInfinite(PowerMath.runtimeHours(500,50,80,100,150)))throw new AssertionError("Charging should have no drain");
        close(PowerMath.chargingHours(500,50,80,50,150),3.125);
        close(PowerMath.chargingHours(500,100,80,50,150),0);
        if(!Double.isInfinite(PowerMath.chargingHours(500,50,80,100,100)))throw new AssertionError("Balanced power cannot charge");
        if(!PowerMath.lowBattery(true,true,20,20))throw new AssertionError("Threshold must be inclusive");
        if(!PowerMath.lowBattery(true,true,0,20))throw new AssertionError("Empty battery must warn");
        if(PowerMath.lowBattery(true,true,21,20))throw new AssertionError("Charged above threshold");
        if(PowerMath.lowBattery(false,true,10,20)||PowerMath.lowBattery(true,false,10,20))throw new AssertionError("Disabled or missing readings must not warn");
        if(!PowerMath.shouldWarn(true,false)||PowerMath.shouldWarn(true,true)||PowerMath.shouldWarn(false,false))throw new AssertionError("Alert debounce failed");
        boolean latch=false;
        for(double reading:new double[]{10,10,80,10}) { boolean low=PowerMath.lowBattery(true,true,reading,20); boolean warn=PowerMath.shouldWarn(low,latch); if(reading==80&&warn)throw new AssertionError("Recovery must clear warning"); latch=low; }
        System.out.println("Power and battery warning checks passed");
    }
}
