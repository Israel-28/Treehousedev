import dev.treehouse.connect.PowerMath;
public class PowerMathTest {
    private static void close(double actual,double expected){if(Math.abs(actual-expected)>0.000001)throw new AssertionError(actual+" != "+expected);}
    public static void main(String[] args){
        close(PowerMath.energyWh(20,5),100);
        close(PowerMath.availableWh(500,50,80),200);
        close(PowerMath.runtimeHours(500,50,80,100,0),2);
        close(PowerMath.runtimeHours(500,50,80,100,50),4);
        close(PowerMath.runtimeHours(500,0,80,100,0),0);
        if(!Double.isInfinite(PowerMath.runtimeHours(500,50,80,100,100)))throw new AssertionError("Balanced input should have no drain");
        if(!Double.isInfinite(PowerMath.runtimeHours(500,50,80,100,150)))throw new AssertionError("Charging should have no drain");
        close(PowerMath.chargingHours(500,50,80,50,150),3.125);
        close(PowerMath.chargingHours(500,100,80,50,150),0);
        if(!Double.isInfinite(PowerMath.chargingHours(500,50,80,100,100)))throw new AssertionError("Balanced power cannot charge");
        System.out.println("Power calculation checks passed");
    }
}
