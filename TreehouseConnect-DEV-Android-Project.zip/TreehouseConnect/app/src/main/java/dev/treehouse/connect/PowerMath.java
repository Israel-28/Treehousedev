package dev.treehouse.connect;

public final class PowerMath {
    private PowerMath() {}
    public static double energyWh(double watts, double hours) { return watts * hours; }
    public static double availableWh(double capacityWh, double percent, double efficiencyPercent) {
        return capacityWh * percent / 100.0 * efficiencyPercent / 100.0;
    }
    public static double runtimeHours(double capacityWh, double percent, double efficiencyPercent, double loadWatts, double inputWatts) {
        double drain = loadWatts - inputWatts;
        return drain > 0 ? availableWh(capacityWh,percent,efficiencyPercent) / drain : Double.POSITIVE_INFINITY;
    }
    public static double chargingHours(double capacityWh, double percent, double efficiencyPercent, double loadWatts, double inputWatts) {
        double surplus = inputWatts - loadWatts;
        return surplus > 0 ? capacityWh * (100-percent) / 100.0 / (surplus * efficiencyPercent / 100.0) : Double.POSITIVE_INFINITY;
    }
}
