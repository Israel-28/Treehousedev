package dev.treehouse.connect;

import android.Manifest;
import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.text.DateFormat;
import java.util.Date;

public class MainActivity extends Activity {
    private android.content.SharedPreferences prefs;
    private LinearLayout root, content, nav;
    private int bg, surface, ink, muted;
    private final int green = Color.rgb(32,168,120);
    private String page = "Home";
    private boolean pendingTest;
    private JSONArray inbox;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("treehouse", MODE_PRIVATE);
        if(state != null) { page = state.getString("page", "Home"); pendingTest = state.getBoolean("pendingTest"); }
        try { inbox = new JSONArray(prefs.getString("inbox", "[]")); } catch(JSONException e) { inbox = new JSONArray(); }
        getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel("updates", "Treehouse updates", NotificationManager.IMPORTANCE_DEFAULT));
        if(state == null && getIntent().getBooleanExtra("openInbox",false)) page = "Inbox";
        render();
    }
    @Override public void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); out.putString("page", page); out.putBoolean("pendingTest", pendingTest); }
    private int dp(int n) { return (int)(getResources().getDisplayMetrics().density*n); }
    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private TextView text(String s, int size, int color) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(0,dp(5),0,dp(5)); return t; }
    private void title(String s) { TextView t = text(s,30,ink); t.setTypeface(null,Typeface.BOLD); content.addView(t); }
    private void note(String s) { content.addView(text(s,15,muted)); }
    private LinearLayout card(String heading, String body) {
        LinearLayout c = column(); c.setPadding(dp(20),dp(16),dp(20),dp(16)); c.setBackground(shape(surface,20));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(14),0,0); content.addView(c,p);
        TextView h = text(heading,19,ink); h.setTypeface(null,Typeface.BOLD); c.addView(h);
        if(!body.isEmpty()) c.addView(text(body,15,muted)); return c;
    }
    private void button(LinearLayout parent, String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setBackground(shape(green,14));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,dp(52)); p.setMargins(0,dp(12),0,dp(2)); parent.addView(b,p); b.setOnClickListener(v -> action.run());
    }
    private void go(String target) { page = target; render(); }
    private void render() {
        String theme = prefs.getString("theme","System");
        boolean dark = theme.equals("Dark") || (theme.equals("System") && (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES);
        bg=Color.parseColor(dark?"#101C19":"#F2F6F3"); surface=Color.parseColor(dark?"#1C2C26":"#FFFFFF"); ink=Color.parseColor(dark?"#EAF5EF":"#183A2D"); muted=Color.parseColor(dark?"#AABFB3":"#64786B");
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(surface);
        getWindow().getDecorView().setSystemUiVisibility(dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        root=column(); root.setBackgroundColor(bg); root.setPadding(dp(20),dp(12),dp(20),0); setContentView(root);
        TextView brand=text("♧  TREEHOUSE CONNECT   /   DEV",12,green); brand.setLetterSpacing(.10f); root.addView(brand);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); content=column(); content.setPadding(0,dp(16),0,dp(24)); scroll.addView(content);
        switch(page) { case "Profile": profile(); break; case "Inbox": notifications(); break; case "Settings": settings(); break; default: home(); }
        nav=new LinearLayout(this); nav.setPadding(0,dp(8),0,dp(8)); root.addView(nav);
        for(String item:new String[]{"Home","Profile","Inbox","Settings"}) { TextView tab=text(item,13,item.equals(page)?green:muted); tab.setGravity(Gravity.CENTER); tab.setPadding(0,dp(14),0,dp(14)); if(item.equals(page))tab.setBackground(shape(surface,12)); nav.addView(tab,new LinearLayout.LayoutParams(0,-2,1)); tab.setOnClickListener(v->go(item)); }
    }
    private void home() {
        title("Your space to grow."); note("Welcome, "+prefs.getString("name","Explorer")+". Make yourself at home.");
        LinearLayout hero=card("A little more connected", "Your profile, preferences, and updates. All together in your Treehouse.");
        button(hero,"Make it yours",()->go("Profile"));
        card("At a glance", unread()+" unread updates  •  "+prefs.getString("theme","System")+" theme\nDevelopment build 0.1.0 • Local mode");
        LinearLayout actions=card("Quick actions", "A few simple ways to get started.");
        button(actions,"Open notification inbox",()->go("Inbox")); button(actions,"Choose your theme",this::chooseTheme);
        card("Built around you", "This first version works offline. Your profile and preferences stay on this device.");
    }
    private EditText input(LinearLayout parent,String hint,String value,boolean multiline) {
        EditText e=new EditText(this); e.setHint(hint); e.setText(value); e.setTextColor(ink); e.setHintTextColor(muted); e.setSingleLine(!multiline); e.setInputType(multiline?android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE:android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES); parent.addView(e,new LinearLayout.LayoutParams(-1,-2)); return e;
    }
    private void profile() {
        title("Your profile"); note("A little introduction goes a long way.");
        String name=prefs.getString("name","Explorer"); LinearLayout identity=card(name.isEmpty()?"Explorer":name,"Local profile • Only visible on this device");
        LinearLayout edit=card("Tell your story","");
        EditText n=input(edit,"Display name",name,false); n.setContentDescription("Display name");
        EditText b=input(edit,"Bio",prefs.getString("bio",""),true); b.setContentDescription("Bio");
        button(edit,"Save profile",()->{ String value=n.getText().toString().trim(); if(value.isEmpty()){n.setError("Please enter a name");return;} if(value.length()>60){n.setError("Use 60 characters or fewer");return;} if(b.length()>500){b.setError("Use 500 characters or fewer");return;} prefs.edit().putString("name",value).putString("bio",b.getText().toString().trim()).apply(); Toast.makeText(this,"Profile saved",Toast.LENGTH_SHORT).show(); render(); });
    }
    private int unread() { int n=0; for(int i=0;i<inbox.length();i++) if(!inbox.optJSONObject(i).optBoolean("read"))n++; return n; }
    private void persistInbox() { prefs.edit().putString("inbox",inbox.toString()).apply(); }
    private void notifications() {
        title("Your updates"); note(unread()+" unread • Local notification inbox");
        LinearLayout tools=card("Stay in the loop","Send a test update to your inbox and, when permitted, your Android notification tray."); button(tools,"Send test notification",this::testNotification);
        if(inbox.length()==0) card("All caught up", "No updates yet. Try sending your first test notification.");
        else {
            button(content,"Mark all as read",()->{for(int i=0;i<inbox.length();i++)try{inbox.getJSONObject(i).put("read",true);}catch(JSONException ignored){} persistInbox();render();});
            for(int i=inbox.length()-1;i>=0;i--) { JSONObject item=inbox.optJSONObject(i); LinearLayout c=card((item.optBoolean("read")?"":"●  ")+item.optString("title"),item.optString("body")+"\n"+DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(item.optLong("time")))); c.setOnClickListener(v->{try{item.put("read",true);}catch(JSONException ignored){}persistInbox();render();}); }
            button(content,"Clear inbox",()->new AlertDialog.Builder(this).setTitle("Clear all updates?").setMessage("This removes the local inbox history.").setNegativeButton("Cancel",null).setPositiveButton("Clear",(d,w)->{inbox=new JSONArray();persistInbox();getSystemService(NotificationManager.class).cancelAll();render();}).show());
        }
    }
    private void testNotification() {
        if(!prefs.getBoolean("notifications",true)){Toast.makeText(this,"Enable notifications in Settings first",Toast.LENGTH_LONG).show();return;}
        if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){pendingTest=true;requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},10);return;}
        sendTest();
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results) { super.onRequestPermissionsResult(request,permissions,results); if(request==10 && pendingTest){pendingTest=false;sendTest();} }
    private void sendTest() {
        try { JSONObject item=new JSONObject();item.put("title","Welcome to your Treehouse");item.put("body","You’re connected. Your local notifications are ready.");item.put("time",System.currentTimeMillis());item.put("read",false);inbox.put(item); if(inbox.length()>100) inbox.remove(0);persistInbox(); }catch(JSONException ignored){}
        NotificationManager manager=getSystemService(NotificationManager.class);
        if(manager.areNotificationsEnabled()) {
            Intent intent=new Intent(this,MainActivity.class).putExtra("openInbox",true).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent tap=PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            manager.notify(1,new Notification.Builder(this,"updates").setSmallIcon(dev.treehouse.connect.R.drawable.ic_tree).setContentTitle("Welcome to your Treehouse").setContentText("Your local notifications are ready.").setContentIntent(tap).setAutoCancel(true).build());
            Toast.makeText(this,"Test notification sent",Toast.LENGTH_SHORT).show();
        }else Toast.makeText(this,"Saved to inbox. Android notifications are blocked in system settings.",Toast.LENGTH_LONG).show();
        render();
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);if(intent.getBooleanExtra("openInbox",false))go("Inbox");}
    private void chooseTheme() {
        String[] themes={"System","Light","Dark"};int selected=java.util.Arrays.asList(themes).indexOf(prefs.getString("theme","System"));
        new AlertDialog.Builder(this).setTitle("Choose appearance").setSingleChoiceItems(themes,selected,(d,w)->{prefs.edit().putString("theme",themes[w]).apply();d.dismiss();render();}).setNegativeButton("Cancel",null).show();
    }
    private void settings() {
        title("Make it your own");note("Small adjustments. A space that feels like you.");
        LinearLayout appearance=card("Appearance", "Current theme: "+prefs.getString("theme","System"));button(appearance,"Change theme",this::chooseTheme);
        LinearLayout alerts=card("Notifications","In-app updates and Android test notifications.");Switch toggle=new Switch(this);toggle.setText("Enable notifications");toggle.setTextColor(ink);toggle.setChecked(prefs.getBoolean("notifications",true));toggle.setPadding(0,dp(16),0,dp(16));alerts.addView(toggle);toggle.setOnCheckedChangeListener((v,on)->{prefs.edit().putBoolean("notifications",on).apply();if(!on)getSystemService(NotificationManager.class).cancelAll();});
        button(alerts,"Android notification settings",()->startActivity(new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE,getPackageName())));
        card("About Treehouse", "Treehouse Connect [DEV]\nVersion 0.1.0 • Native Android\nOffline development edition\nNo account, cloud sync, or remote push service is connected.");
        LinearLayout data=card("Your data", "Your profile, theme, and inbox are stored locally. Resetting removes them from this device.");
        button(data,"Reset local data",()->new AlertDialog.Builder(this).setTitle("Reset Treehouse?").setMessage("Your profile, settings, and inbox will be deleted.").setNegativeButton("Cancel",null).setPositiveButton("Reset",(d,w)->{prefs.edit().clear().apply();inbox=new JSONArray();getSystemService(NotificationManager.class).cancelAll();go("Home");}).show());
    }
}
