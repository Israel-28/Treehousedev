package dev.treehouse.connect;

import android.Manifest;
import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.text.DateFormat;
import java.util.Date;

public class MainActivity extends Activity {
    private android.content.SharedPreferences prefs;
    private LinearLayout root, content, nav;
    private int bg, surface, ink, muted;
    private final int green = Color.rgb(32,168,120);
    private String page = "Home";
    private boolean pendingTest;
    private JSONArray inbox, devices, energyLog, temperatureLog;
    private boolean weatherLoading;
    private String weatherError = "";
    private JSONObject weather;
    private final java.util.concurrent.ExecutorService worker = java.util.concurrent.Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("treehouse", MODE_PRIVATE);
        if(state != null) { page = state.getString("page", "Home"); pendingTest = state.getBoolean("pendingTest"); }
        try { inbox = new JSONArray(prefs.getString("inbox", "[]")); } catch(JSONException e) { inbox = new JSONArray(); }
        getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel("updates", "Treehouse updates", NotificationManager.IMPORTANCE_DEFAULT));
        if(state == null && getIntent().getBooleanExtra("openInbox",false)) page = "Inbox";
        devices = readArray("devices"); energyLog = readArray("energyLog"); temperatureLog = readArray("temperatureLog");
        try { weather = new JSONObject(prefs.getString("weather", "{}")); } catch(JSONException e) { weather = new JSONObject(); }
        render();
    }
    @Override protected void onDestroy() { super.onDestroy(); worker.shutdownNow(); }
    @Override protected void onResume() { super.onResume(); if(prefs != null && (page.equals("Internet") || page.equals("Home"))) render(); }
    @Override public void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); out.putString("page", page); out.putBoolean("pendingTest", pendingTest); }
    private int dp(int n) { return (int)(getResources().getDisplayMetrics().density*n); }
    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private TextView text(String s, int size, int color) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(0,dp(5),0,dp(5)); return t; }
    private void title(String s) { TextView t = text(s,30,ink); t.setTypeface(null,Typeface.BOLD); content.addView(t); }
    private void note(String s) { content.addView(text(s,15,muted)); }
    private LinearLayout card(String heading, String body) {
        LinearLayout c = column(); c.setPadding(dp(20),dp(16),dp(20),dp(16)); c.setBackground(shape(surface,20));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(14),0,0); content.addView(c,p);
        TextView h = text(heading,19,ink); h.setTypeface(null,Typeface.BOLD); c.addView(h);
        if(!body.isEmpty()) c.addView(text(body,15,muted)); return c;
    }
    private void button(LinearLayout parent, String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setBackground(shape(green,14));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,dp(52)); p.setMargins(0,dp(12),0,dp(2)); parent.addView(b,p); b.setOnClickListener(v -> action.run());
    }
    private void go(String target) { page = target; render(); }
    private void render() {
        String theme = prefs.getString("theme","Dark");
        boolean dark = theme.equals("Dark") || (theme.equals("System") && (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES);
        bg=Color.parseColor(dark?"#101C19":"#F2F6F3"); surface=Color.parseColor(dark?"#1C2C26":"#FFFFFF"); ink=Color.parseColor(dark?"#EAF5EF":"#183A2D"); muted=Color.parseColor(dark?"#AABFB3":"#64786B");
        setTheme(dark ? android.R.style.Theme_Material_NoActionBar : android.R.style.Theme_Material_Light_NoActionBar);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(surface);
        getWindow().getDecorView().setSystemUiVisibility(dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        root=column(); root.setBackgroundColor(bg); root.setPadding(dp(20),dp(12),dp(20),0); setContentView(root);
        TextView brand=text("♧  TREEHOUSE CONNECT   /   DEV 02",12,green); brand.setLetterSpacing(.10f); root.addView(brand);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); content=column(); content.setPadding(0,dp(16),0,dp(24)); scroll.addView(content);
        switch(page) { case "Power": power(); break; case "Weather": weatherPage(); break; case "Internet": internet(); break; case "Profile": profile(); break; case "Inbox": notifications(); break; case "Settings": settings(); break; default: home(); }
        nav=new LinearLayout(this); nav.setPadding(0,dp(8),0,dp(8)); root.addView(nav);
        for(String item:new String[]{"Home","Power","Weather","Internet","Settings"}) { TextView tab=text(item,13,item.equals(page)?green:muted); tab.setGravity(Gravity.CENTER); tab.setPadding(0,dp(14),0,dp(14)); if(item.equals(page))tab.setBackground(shape(surface,12)); nav.addView(tab,new LinearLayout.LayoutParams(0,-2,1)); tab.setOnClickListener(v->go(item)); }
    }
    private void home() {
        title("Treehouse control."); note("UPPER DECK + LOWER LOUNGE   •   DEVELOPMENT");
        LinearLayout hero = card("POWER STATION", devices.length()==0 ? "Add your lights, chargers, and other equipment to start estimating." : "Based on your equipment entries. No power station is paired.");
        double load = totalWatts(), input = number("input",0);
        TextView big = text(f(load)+" W",42,green); big.setTypeface(null,Typeface.BOLD); hero.addView(big);
        hero.addView(text("Estimated active load   /   "+f(input)+" W charging input",14,muted));
        if(prefs.contains("capacity")) hero.addView(text(batterySummary(),16,ink));
        button(hero,"Manage power & equipment",()->go("Power"));
        LinearLayout energy = card("TODAY’S ENERGY", f(totalWh())+" Wh planned use • "+f(totalWh()/1000)+" kWh\nEstimated cost: $"+String.format(java.util.Locale.US,"%.2f",totalWh()/1000*number("rate",0.15))+" at your configured rate");
        note("Calculated from device watts × hours/day. Logged energy is recorded separately.");
        LinearLayout conditions = card("OUTDOOR CONDITIONS", weatherSummary()); button(conditions,"Weather & temperature",()->go("Weather"));
        card("CONNECTION",networkSummary());
        LinearLayout activity = card("YOUR TREEHOUSE", "Track power, charging, and conditions from one place.");
        button(activity,"Open alerts ("+unread()+" unread)",()->go("Inbox"));
    }
    private EditText input(LinearLayout parent,String hint,String value,boolean multiline) {
        EditText e=new EditText(this); e.setHint(hint); e.setText(value); e.setTextColor(ink); e.setHintTextColor(muted); e.setSingleLine(!multiline); e.setInputType(multiline?android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE:android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES); parent.addView(e,new LinearLayout.LayoutParams(-1,-2)); return e;
    }
    private void profile() {
        title("Your profile"); note("A little introduction goes a long way.");
        String name=prefs.getString("name","Explorer"); LinearLayout identity=card(name.isEmpty()?"Explorer":name,"Local profile • Only visible on this device");
        LinearLayout edit=card("Tell your story","");
        EditText n=input(edit,"Display name",name,false); n.setContentDescription("Display name");
        EditText b=input(edit,"Bio",prefs.getString("bio",""),true); b.setContentDescription("Bio");
        button(edit,"Save profile",()->{ String value=n.getText().toString().trim(); if(value.isEmpty()){n.setError("Please enter a name");return;} if(value.length()>60){n.setError("Use 60 characters or fewer");return;} if(b.length()>500){b.setError("Use 500 characters or fewer");return;} prefs.edit().putString("name",value).putString("bio",b.getText().toString().trim()).apply(); Toast.makeText(this,"Profile saved",Toast.LENGTH_SHORT).show(); render(); });
    }
    private int unread() { int n=0; for(int i=0;i<inbox.length();i++) if(!inbox.optJSONObject(i).optBoolean("read"))n++; return n; }
    private void persistInbox() { prefs.edit().putString("inbox",inbox.toString()).apply(); }
    private void notifications() {
        title("Your updates"); note(unread()+" unread • Local notification inbox");
        LinearLayout tools=card("Stay in the loop","Send a test update to your inbox and, when permitted, your Android notification tray."); button(tools,"Send test notification",this::testNotification);
        if(inbox.length()==0) card("All caught up", "No updates yet. Try sending your first test notification.");
        else {
            button(content,"Mark all as read",()->{for(int i=0;i<inbox.length();i++)try{inbox.getJSONObject(i).put("read",true);}catch(JSONException ignored){} persistInbox();render();});
            for(int i=inbox.length()-1;i>=0;i--) { JSONObject item=inbox.optJSONObject(i); LinearLayout c=card((item.optBoolean("read")?"":"●  ")+item.optString("title"),item.optString("body")+"\n"+DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(item.optLong("time")))); c.setOnClickListener(v->{try{item.put("read",true);}catch(JSONException ignored){}persistInbox();render();}); }
            button(content,"Clear inbox",()->new AlertDialog.Builder(this).setTitle("Clear all updates?").setMessage("This removes the local inbox history.").setNegativeButton("Cancel",null).setPositiveButton("Clear",(d,w)->{inbox=new JSONArray();persistInbox();getSystemService(NotificationManager.class).cancelAll();render();}).show());
        }
    }
    private void testNotification() {
        if(!prefs.getBoolean("notifications",true)){Toast.makeText(this,"Enable notifications in Settings first",Toast.LENGTH_LONG).show();return;}
        if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){pendingTest=true;requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},10);return;}
        sendTest();
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results) { super.onRequestPermissionsResult(request,permissions,results); if(request==10 && pendingTest){pendingTest=false;sendTest();} }
    private void sendTest() {
        try { JSONObject item=new JSONObject();item.put("title","Treehouse update");item.put("body","Your local notification inbox is ready.");item.put("time",System.currentTimeMillis());item.put("read",false);inbox.put(item); if(inbox.length()>100) inbox.remove(0);persistInbox(); }catch(JSONException ignored){}
        NotificationManager manager=getSystemService(NotificationManager.class);
        if(manager.areNotificationsEnabled()) {
            Intent intent=new Intent(this,MainActivity.class).putExtra("openInbox",true).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent tap=PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            manager.notify(1,new Notification.Builder(this,"updates").setSmallIcon(dev.treehouse.connect.R.drawable.ic_tree).setContentTitle("Treehouse update").setContentText("Your local notifications are ready.").setContentIntent(tap).setAutoCancel(true).build());
            Toast.makeText(this,"Test notification sent",Toast.LENGTH_SHORT).show();
        }else Toast.makeText(this,"Saved to inbox. Android notifications are blocked in system settings.",Toast.LENGTH_LONG).show();
        render();
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);if(intent.getBooleanExtra("openInbox",false))go("Inbox");}
    private void chooseTheme() {
        String[] themes={"System","Light","Dark"};int selected=java.util.Arrays.asList(themes).indexOf(prefs.getString("theme","Dark"));
        new AlertDialog.Builder(this).setTitle("Choose appearance").setSingleChoiceItems(themes,selected,(d,w)->{prefs.edit().putString("theme",themes[w]).apply();d.dismiss();render();}).setNegativeButton("Cancel",null).show();
    }
    private void settings() {
        title("Make it your own");note("Small adjustments. A space that feels like you.");
        LinearLayout appearance=card("Appearance", "Current theme: "+prefs.getString("theme","Dark"));button(appearance,"Change theme",this::chooseTheme);
        LinearLayout alerts=card("Notifications","In-app updates and Android test notifications.");Switch toggle=new Switch(this);toggle.setText("Enable notifications");toggle.setTextColor(ink);toggle.setChecked(prefs.getBoolean("notifications",true));toggle.setPadding(0,dp(16),0,dp(16));alerts.addView(toggle);toggle.setOnCheckedChangeListener((v,on)->{prefs.edit().putBoolean("notifications",on).apply();if(!on)getSystemService(NotificationManager.class).cancelAll();});
        button(alerts,"Android notification settings",()->startActivity(new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE,getPackageName())));
        card("About Treehouse", "Treehouse Connect [DEV]\nVersion 0.2.0 • Native Android\nTreehouse utility edition\nPower estimates and logs stay on this device. Weather uses Open-Meteo. No remote device control or hardware pairing is connected.");
        button(content,"Edit profile",()->go("Profile"));
        button(content,"Notification inbox",()->go("Inbox"));
        LinearLayout data=card("Your data", "Your profile, theme, and inbox are stored locally. Resetting removes them from this device.");
        button(data,"Reset local data",()->new AlertDialog.Builder(this).setTitle("Reset Treehouse?").setMessage("Your profile, settings, and inbox will be deleted.").setNegativeButton("Cancel",null).setPositiveButton("Reset",(d,w)->{prefs.edit().clear().apply();inbox=new JSONArray();devices=new JSONArray();energyLog=new JSONArray();temperatureLog=new JSONArray();weather=new JSONObject();getSystemService(NotificationManager.class).cancelAll();go("Home");}).show());
    }
    private JSONArray readArray(String key) {
        try { return new JSONArray(prefs.getString(key,"[]")); } catch(JSONException e) { return new JSONArray(); }
    }
    private void saveArray(String key,JSONArray data) { prefs.edit().putString(key,data.toString()).apply(); }
    private double number(String key,double fallback) { try { return Double.parseDouble(prefs.getString(key,Double.toString(fallback))); }catch(Exception e){return fallback;} }
    private String f(double n) { return String.format(java.util.Locale.US,"%.1f",n); }
    private String stamp(long time) { return DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(time)); }
    private double totalWatts() { double n=0;for(int i=0;i<devices.length();i++){JSONObject d=devices.optJSONObject(i);if(d.optBoolean("active"))n+=d.optDouble("watts");}return n; }
    private double totalWh() { double n=0;for(int i=0;i<devices.length();i++){JSONObject d=devices.optJSONObject(i);n+=PowerMath.energyWh(d.optDouble("watts"),d.optDouble("hours"));}return n; }
    private String batterySummary() {
        double capacity=number("capacity",0),percent=number("battery",100),eff=number("efficiency",85),load=totalWatts(),incoming=number("input",0);
        String status=f(percent)+"% manually entered • "+f(capacity)+" Wh capacity\n";
        if(load>incoming) return status+"Estimated runtime: "+f(PowerMath.runtimeHours(capacity,percent,eff,load,incoming))+" hours";
        if(incoming>load && percent<100) return status+"Estimated time to full: "+f(PowerMath.chargingHours(capacity,percent,eff,load,incoming))+" hours";
        return status+(percent>=100 && incoming>=load ? "Battery full at entered level; input covers estimated load." : "Input matches load; no estimated net drain.");
    }
    private EditText numeric(LinearLayout parent,String label,String value) {
        parent.addView(text(label,14,muted)); EditText e=input(parent,label,value,false);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);return e;
    }
    private double parse(EditText e,double min,double max) {
        double n;try{n=Double.parseDouble(e.getText().toString().trim());}catch(Exception ex){e.setError("Enter a number");throw new IllegalArgumentException();}
        if(!Double.isFinite(n)||n<min||n>max){e.setError("Enter a value from "+min+" to "+max);throw new IllegalArgumentException();}return n;
    }
    private void power() {
        title("Power & charging");note("MANUAL INPUTS   •   ESTIMATES, NOT METER READINGS");
        card("POWER FLOW",f(number("input",0))+" W in → "+f(totalWatts())+" W active load\n"+(prefs.contains("capacity")?batterySummary():"Set your power station capacity below."));
        LinearLayout station=card("Your power station", "Enter the values from your station’s display or label.");
        EditText capacity=numeric(station,"Capacity (Wh)",prefs.getString("capacity",""));
        EditText battery=numeric(station,"Battery level (%)",prefs.getString("battery","100"));
        EditText incoming=numeric(station,"Charging input (W)",prefs.getString("input","0"));
        EditText efficiency=numeric(station,"Usable / charging efficiency (%)",prefs.getString("efficiency","85"));
        EditText rate=numeric(station,"Electricity rate ($/kWh)",prefs.getString("rate","0.15"));
        button(station,"Save station readings",()->{try{
            double c=parse(capacity,1,1000000),b=parse(battery,0,100),in=parse(incoming,0,100000),ef=parse(efficiency,1,100),r=parse(rate,0,100);
            prefs.edit().putString("capacity",Double.toString(c)).putString("battery",Double.toString(b)).putString("input",Double.toString(in)).putString("efficiency",Double.toString(ef)).putString("rate",Double.toString(r)).putLong("powerUpdated",System.currentTimeMillis()).apply();render();
        }catch(IllegalArgumentException ignored){}});
        if(prefs.contains("powerUpdated")) note("Readings saved "+stamp(prefs.getLong("powerUpdated",0))+". Update them when conditions change.");
        note("Runtime assumes constant load/input. Charging slows near full. The 85% efficiency and $0.15 rate are editable starting assumptions.");
        LinearLayout equipment=card("Equipment",devices.length()+" devices • "+f(totalWh())+" Wh planned per day");button(equipment,"Add equipment",()->editDevice(-1));
        for(int i=0;i<devices.length();i++) {
            final int index=i;JSONObject d=devices.optJSONObject(i);LinearLayout c=card(d.optString("name"),d.optString("zone")+" • "+f(d.optDouble("watts"))+" W • "+f(d.optDouble("hours"))+" h/day\n"+f(PowerMath.energyWh(d.optDouble("watts"),d.optDouble("hours")))+" Wh/day planned");
            Switch active=new Switch(this);active.setText("Include in active load estimate");active.setTextColor(ink);active.setChecked(d.optBoolean("active"));c.addView(active);active.setOnCheckedChangeListener((v,on)->{try{d.put("active",on);}catch(JSONException ignored){}saveArray("devices",devices);render();});
            button(c,"Edit equipment",()->editDevice(index));
            button(c,"Remove equipment",()->new AlertDialog.Builder(this).setTitle("Remove "+d.optString("name")+"?").setNegativeButton("Cancel",null).setPositiveButton("Remove",(dialog,which)->{devices.remove(index);saveArray("devices",devices);render();}).show());
        }
        LinearLayout log=card("Energy journal", "Record meter readings or estimates. Entries keep their source label.");button(log,"Log energy usage",this::logEnergy);
        double sum=0;for(int i=0;i<energyLog.length();i++)sum+=energyLog.optJSONObject(i).optDouble("wh");log.addView(text("Journal total: "+f(sum)+" Wh across "+energyLog.length()+" entries",15,ink));
        for(int i=energyLog.length()-1;i>=Math.max(0,energyLog.length()-10);i--){JSONObject e=energyLog.optJSONObject(i);log.addView(text(f(e.optDouble("wh"))+" Wh • "+e.optString("source")+"\n"+stamp(e.optLong("time"))+" • "+e.optString("note"),14,muted));}
        if(energyLog.length()>0) button(log,"Clear energy journal",()->new AlertDialog.Builder(this).setTitle("Clear energy journal?").setNegativeButton("Cancel",null).setPositiveButton("Clear",(d,w)->{energyLog=new JSONArray();saveArray("energyLog",energyLog);render();}).show());
    }
    private void editDevice(int index) {
        JSONObject d=index<0?new JSONObject():devices.optJSONObject(index);
        LinearLayout form=column();form.setPadding(dp(20),dp(8),dp(20),dp(8));
        EditText name=input(form,"Device name (e.g. deck lights)",d.optString("name"),false);
        EditText watts=numeric(form,"Device wattage (W)",index<0?"":Double.toString(d.optDouble("watts")));
        EditText hours=numeric(form,"Planned hours per day",index<0?"":Double.toString(d.optDouble("hours")));
        Spinner zone=new Spinner(this);String[] zones={"Upper deck","Lower lounge","Both levels","Other"};zone.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,zones));zone.setSelection(Math.max(0,java.util.Arrays.asList(zones).indexOf(d.optString("zone"))));form.addView(zone);
        ScrollView sc=new ScrollView(this);sc.addView(form);AlertDialog dialog=new AlertDialog.Builder(this).setTitle(index<0?"Add equipment":"Edit equipment").setView(sc).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();
        dialog.setOnShowListener(v->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(button->{try{
            String n=name.getText().toString().trim();if(n.isEmpty()||n.length()>60){name.setError("Enter a name up to 60 characters");return;}
            double w=parse(watts,0,100000),h=parse(hours,0,24);JSONObject item=new JSONObject();item.put("name",n);item.put("watts",w);item.put("hours",h);item.put("zone",zone.getSelectedItem().toString());item.put("active",index<0||d.optBoolean("active"));
            if(index<0)devices.put(item);else devices.put(index,item);saveArray("devices",devices);dialog.dismiss();render();
        }catch(IllegalArgumentException|JSONException ignored){}}));dialog.show();
    }
    private void logEnergy() {
        LinearLayout form=column();form.setPadding(dp(20),0,dp(20),0);EditText wh=numeric(form,"Energy used (Wh)","");EditText note=input(form,"Period / notes (e.g. Thursday evening)","",false);
        Spinner source=new Spinner(this);source.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Manual meter reading","Estimate"}));form.addView(source);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Log energy usage").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();dialog.setOnShowListener(v->dialog.getButton(-1).setOnClickListener(button->{try{double value=parse(wh,0,100000000);JSONObject item=new JSONObject();item.put("wh",value);item.put("note",note.getText().toString());item.put("source",source.getSelectedItem().toString());item.put("time",System.currentTimeMillis());energyLog.put(item);saveArray("energyLog",energyLog);dialog.dismiss();render();}catch(IllegalArgumentException|JSONException ignored){}}));dialog.show();
    }
    private String weatherSummary() {
        JSONObject current=weather.optJSONObject("current");if(current==null)return "No weather loaded. Choose a town and refresh.\nOutdoor weather is separate from treehouse readings.";
        return weather.optString("place")+" • "+f(current.optDouble("temperature_2m"))+"°F\n"+weatherCode(current.optInt("weather_code"))+" • Wind "+f(current.optDouble("wind_speed_10m"))+" mph\n"+"Fetched "+stamp(weather.optLong("fetched"))+" (cached until refreshed)";
    }
    private String weatherCode(int c) { if(c==0)return "Clear";if(c<=3)return "Cloudy / partly cloudy";if(c<=48)return "Fog";if(c<=67)return "Rain / drizzle";if(c<=77)return "Snow";if(c<=82)return "Rain showers";if(c<=86)return "Snow showers";return "Thunderstorms"; }
    private void weatherPage() {
        title("Weather & climate");note("OUTDOOR FORECAST   +   YOUR TREEHOUSE READINGS");
        LinearLayout outside=card("Outside",weatherSummary());JSONObject current=weather.optJSONObject("current");if(current!=null)outside.addView(text("Humidity "+current.optInt("relative_humidity_2m")+"% • Feels like "+f(current.optDouble("apparent_temperature"))+"°F\nModel timestamp: "+current.optString("time"),14,muted));
        LinearLayout location=card("Weather location", "Search a town, optionally followed by its two-letter country code (e.g. Cornelius, US). If results are ambiguous, choose your location.");EditText town=input(location,"Town, country",prefs.getString("town","Cornelius, US"),false);
        button(location,weatherLoading?"Loading weather…":"Refresh weather",()->{if(!weatherLoading){String q=town.getText().toString().trim();if(q.length()<2||q.length()>100){town.setError("Enter a town name (2–100 characters)");return;}fetchWeather(q);}});
        if(!weatherError.isEmpty())note(weatherError);
        note("Weather: Open-Meteo • https://open-meteo.com • Outdoor model data, not a treehouse sensor. Refresh sends the entered town / selected town coordinates to Open-Meteo. No GPS permission is used.");
        LinearLayout inside=card("Treehouse temperature", "Record your thermometer’s reading. Nothing is measured automatically.");button(inside,"Log temperature",this::logTemperature);
        for(int i=temperatureLog.length()-1;i>=Math.max(0,temperatureLog.length()-10);i--){JSONObject t=temperatureLog.optJSONObject(i);inside.addView(text(f(t.optDouble("fahrenheit"))+"°F • "+t.optString("zone")+"\nManual reading • "+stamp(t.optLong("time")),15,ink));}
        if(temperatureLog.length()==0)inside.addView(text("No readings recorded yet.",15,muted));
        if(temperatureLog.length()>0)button(inside,"Clear temperature history",()->new AlertDialog.Builder(this).setTitle("Clear temperature history?").setNegativeButton("Cancel",null).setPositiveButton("Clear",(d,w)->{temperatureLog=new JSONArray();saveArray("temperatureLog",temperatureLog);render();}).show());
    }
    private JSONObject jsonGet(String address) throws Exception {
        javax.net.ssl.HttpsURLConnection c=(javax.net.ssl.HttpsURLConnection)new java.net.URL(address).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(12000);
        try{if(c.getResponseCode()!=200)throw new java.io.IOException("Service unavailable");try(java.io.InputStream in=c.getInputStream();java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))!=-1){out.write(buffer,0,n);if(out.size()>1000000)throw new java.io.IOException("Response too large");}return new JSONObject(out.toString("UTF-8"));}}finally{c.disconnect();}
    }
    private void fetchWeather(String query) {
        weatherLoading=true;weatherError="";prefs.edit().putString("town",query).apply();render();
        worker.execute(()->{try{
            String[] parts=query.split(",",2);String country=parts.length>1?parts[1].trim():"";String filter=country.matches("[A-Za-z]{2}")?"&countryCode="+country.toUpperCase(java.util.Locale.US):"";
            JSONObject result=jsonGet("https://geocoding-api.open-meteo.com/v1/search?name="+java.net.URLEncoder.encode(parts[0].trim(),"UTF-8")+"&count=5&language=en&format=json"+filter);
            JSONArray places=result.optJSONArray("results");if(places==null||places.length()==0)throw new java.io.IOException("Town not found");
            runOnUiThread(()->{if(isDestroyed())return;if(places.length()==1)loadForecast(places.optJSONObject(0));else{
                String[] labels=new String[places.length()];for(int i=0;i<labels.length;i++){JSONObject p=places.optJSONObject(i);labels[i]=p.optString("name")+", "+p.optString("admin1")+", "+p.optString("country");}
                new AlertDialog.Builder(this).setTitle("Choose weather location").setItems(labels,(dialog,index)->loadForecast(places.optJSONObject(index))).setNegativeButton("Cancel",(d,w)->{weatherLoading=false;render();}).setOnCancelListener(d->{weatherLoading=false;render();}).show();
            }});
        }catch(Exception e){weatherFailure("Couldn’t load weather. Check your connection and town name, then try again. Existing cached weather is unchanged.");}});
    }
    private void loadForecast(JSONObject place) {
        worker.execute(()->{try{JSONObject result=jsonGet("https://api.open-meteo.com/v1/forecast?latitude="+place.getDouble("latitude")+"&longitude="+place.getDouble("longitude")+"&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&temperature_unit=fahrenheit&wind_speed_unit=mph&timezone=auto");
            JSONObject cur=result.getJSONObject("current");if(!cur.has("temperature_2m")||cur.isNull("temperature_2m"))throw new java.io.IOException("Missing temperature");
            result.put("place",place.optString("name")+", "+place.optString("admin1")+", "+place.optString("country"));result.put("fetched",System.currentTimeMillis());
            runOnUiThread(()->{if(isDestroyed())return;weather=result;weatherLoading=false;weatherError="";prefs.edit().putString("weather",result.toString()).apply();render();});
        }catch(Exception e){weatherFailure("Weather service unavailable. Try again later. Existing cached weather is unchanged.");}});
    }
    private void weatherFailure(String message){runOnUiThread(()->{if(isDestroyed())return;weatherLoading=false;weatherError=message;render();});}
    private void logTemperature(){
        LinearLayout form=column();form.setPadding(dp(20),0,dp(20),0);EditText temp=numeric(form,"Temperature (°F)","");Spinner zone=new Spinner(this);zone.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Upper deck","Lower lounge","Outside"}));form.addView(zone);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Manual thermometer reading").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();dialog.setOnShowListener(v->dialog.getButton(-1).setOnClickListener(button->{try{double value=parse(temp,-100,160);JSONObject item=new JSONObject();item.put("fahrenheit",value);item.put("zone",zone.getSelectedItem().toString());item.put("time",System.currentTimeMillis());temperatureLog.put(item);saveArray("temperatureLog",temperatureLog);dialog.dismiss();render();}catch(IllegalArgumentException|JSONException ignored){}}));dialog.show();
    }
    private String networkSummary(){
        android.net.ConnectivityManager cm=getSystemService(android.net.ConnectivityManager.class);android.net.NetworkCapabilities c=cm.getNetworkCapabilities(cm.getActiveNetwork());
        if(c==null)return "No active connection detected on this phone.";
        String type=c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)?"Wi-Fi":c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR)?"Cellular":c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET)?"Ethernet":"Other network";
        if(c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_VPN))type+=" / VPN";
        return type+" • "+(c.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)?"Android reports internet available":"Internet not validated by Android")+"\n"+(cm.isActiveNetworkMetered()?"Metered connection":"Unmetered connection")+"\nChecked "+stamp(System.currentTimeMillis());
    }
    private void internet(){
        title("Internet connection");note("THIS PHONE’S CONNECTION   •   NOT A REMOTE TREEHOUSE SENSOR");
        LinearLayout live=card("Network status",networkSummary());button(live,"Refresh connection status",this::render);
        button(live,"Open Wi-Fi settings",()->startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)));
        LinearLayout record=card("Treehouse internet notes", "Keep your provider, router name, and last speed-test result here. Don’t enter passwords.");
        EditText provider=input(record,"Provider / router",prefs.getString("provider",""),false);
        EditText down=numeric(record,"Last measured download (Mbps)",prefs.getString("download",""));
        EditText up=numeric(record,"Last measured upload (Mbps)",prefs.getString("upload",""));
        EditText notes=input(record,"Connection notes",prefs.getString("networkNotes",""),true);
        button(record,"Save internet notes",()->{try{
            String d=down.getText().toString().trim(),u=up.getText().toString().trim();if(!d.isEmpty())parse(down,0,100000);if(!u.isEmpty())parse(up,0,100000);
            prefs.edit().putString("provider",provider.getText().toString()).putString("download",d).putString("upload",u).putString("networkNotes",notes.getText().toString()).putLong("networkUpdated",System.currentTimeMillis()).apply();Toast.makeText(this,"Internet notes saved",Toast.LENGTH_SHORT).show();render();
        }catch(IllegalArgumentException ignored){}});
        if(prefs.contains("networkUpdated"))note("Manual notes updated "+stamp(prefs.getLong("networkUpdated",0)));
        note("Speed values are manual records, not an automatic speed test. Connection status describes this phone wherever it is located.");
    }

}
