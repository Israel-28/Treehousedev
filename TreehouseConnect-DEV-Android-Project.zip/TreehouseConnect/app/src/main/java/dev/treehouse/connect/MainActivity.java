package dev.treehouse.connect;

import android.Manifest;
import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.text.DateFormat;
import java.util.Date;

public class MainActivity extends Activity {
    private android.content.SharedPreferences prefs;
    private LinearLayout root, content, nav;
    private int bg, surface, ink, muted;
    private boolean darkMode;
    private final int green = Color.rgb(153,120,75);
    private String page = "Home";
    private boolean pendingTest;
    private JSONArray inbox, devices, energyLog, temperatureLog, supplies, tasks;
    private android.content.SharedPreferences registry;
    private JSONArray accounts;
    private String activeAccount;
    private int accountEpoch;
    private final String[] levels = {"Level 1 • Lower lounge", "Level 2 • Kitchen deck", "Level 3 • Chair area", "All levels", "Other"};
    private boolean weatherLoading;
    private String weatherError = "";
    private JSONObject weather;
    private final java.util.concurrent.ExecutorService worker = java.util.concurrent.Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        registry = getSharedPreferences("treehouse_accounts", MODE_PRIVATE);
        try { accounts = new JSONArray(registry.getString("accounts","[]")); } catch(JSONException e) { accounts = new JSONArray(); }
        if(accounts.length()==0) { try { JSONObject first=new JSONObject();first.put("id","default");first.put("name","Main account");accounts.put(first); } catch(JSONException ignored){} saveAccounts(); }
        activeAccount=registry.getString("active","default");
        boolean found=false;for(int i=0;i<accounts.length();i++)if(accounts.optJSONObject(i).optString("id").equals(activeAccount))found=true;
        if(!found)activeAccount=accounts.optJSONObject(0).optString("id");
        prefs = getSharedPreferences(activeAccount.equals("default")?"treehouse":"treehouse_"+activeAccount, MODE_PRIVATE);
        if(state != null) { page = state.getString("page", "Home"); pendingTest = state.getBoolean("pendingTest"); }
        try { inbox = new JSONArray(prefs.getString("inbox", "[]")); } catch(JSONException e) { inbox = new JSONArray(); }
        getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel("updates", "Treehouse updates", NotificationManager.IMPORTANCE_DEFAULT));
        if(state == null && getIntent().getBooleanExtra("openInbox",false)) page = "Inbox";
        devices = readArray("devices"); energyLog = readArray("energyLog"); temperatureLog = readArray("temperatureLog");
        try { weather = new JSONObject(prefs.getString("weather", "{}")); } catch(JSONException e) { weather = new JSONObject(); }
        supplies=readArray("supplies");tasks=readArray("tasks");
        migrateLevels();
        render();
    }
    @Override protected void onDestroy() { super.onDestroy(); worker.shutdownNow(); }
    @Override protected void onResume() { super.onResume(); if(prefs != null && (page.equals("Internet") || page.equals("Home"))) render(); }
    @Override public void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); out.putString("page", page); out.putBoolean("pendingTest", pendingTest); }
    private int dp(int n) { return (int)(getResources().getDisplayMetrics().density*n); }
    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private TextView text(String s, int size, int color) { TextView t = new TextView(this); t.setText(s); t.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL)); t.setTextSize(size); t.setTextColor(color); t.setPadding(0,dp(5),0,dp(5)); return t; }
    private void title(String s) { TextView t = text(s,32,ink); t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL)); content.addView(t); }
    private void note(String s) { content.addView(text(s,15,muted)); }
    private LinearLayout card(String heading, String body) {
        LinearLayout c = column(); c.setPadding(dp(20),dp(16),dp(20),dp(16)); GradientDrawable panel=shape(surface,22); panel.setStroke(dp(1),Color.parseColor(darkMode?"#293C34":"#E4E9E0")); c.setBackground(panel);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(14),0,0); content.addView(c,p);
        TextView h = text(heading,19,ink); h.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL)); c.addView(h);
        if(!body.isEmpty()) c.addView(text(body,15,muted)); return c;
    }
    private void button(LinearLayout parent, String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setTextSize(15); boolean secondary=label.startsWith("Remove")||label.startsWith("Clear")||label.startsWith("Reset")||label.startsWith("Edit")||label.startsWith("Android"); b.setTextColor(secondary?ink:Color.WHITE); b.setBackground(shape(secondary?(darkMode?Color.parseColor("#30443A"):Color.parseColor("#EAF0E6")):green,16)); b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL)); b.setElevation(0);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,dp(52)); p.setMargins(0,dp(12),0,dp(2)); parent.addView(b,p); b.setOnClickListener(v -> action.run());
        b.setOnTouchListener((view,event)->{if(!motionAllowed())return false;int a=event.getActionMasked();if(a==android.view.MotionEvent.ACTION_DOWN)view.animate().scaleX(.97f).scaleY(.97f).setDuration(90).start();else if(a==android.view.MotionEvent.ACTION_UP||a==android.view.MotionEvent.ACTION_CANCEL)view.animate().scaleX(1).scaleY(1).setDuration(120).start();return false;});
    }
    private void go(String target) { page = target; render(); }
    private void render() {
        String theme = prefs.getString("theme","Dark");
        boolean dark = theme.equals("Dark") || (theme.equals("System") && (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES);
        darkMode=dark;
        bg=Color.parseColor(dark?"#181B18":"#F7F3EA"); surface=Color.parseColor(dark?"#242923":"#FFFCF6"); ink=Color.parseColor(dark?"#F4EFE3":"#29372E"); muted=Color.parseColor(dark?"#B6B9AB":"#777A6D");
        setTheme(dark ? android.R.style.Theme_Material_NoActionBar : android.R.style.Theme_Material_Light_NoActionBar);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(surface);
        getWindow().getDecorView().setSystemUiVisibility(dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        root=column(); root.setBackgroundColor(bg); root.setPadding(dp(22),dp(12),dp(22),0); setContentView(root);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);root.addView(top);
        TextView brand=text("TREEHOUSE",13,ink);brand.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));brand.setLetterSpacing(.16f);top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView accountBar=text(accountName()+"  ⌄",12,muted);accountBar.setPadding(dp(12),dp(10),dp(12),dp(10));accountBar.setBackground(shape(surface,24));top.addView(accountBar);accountBar.setOnClickListener(v->go("Accounts"));accountBar.setContentDescription("Switch account. Current account "+accountName());
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); content=column(); content.setPadding(0,dp(16),0,dp(24)); scroll.addView(content);
        switch(page) { case "Accounts": accountPage(); break; case "Supplies": suppliesPage(); break; case "Tasks": tasksPage(); break; case "Power": power(); break; case "Weather": weatherPage(); break; case "Internet": internet(); break; case "Profile": profile(); break; case "Inbox": notifications(); break; case "Settings": settings(); break; default: home(); }
        nav=new LinearLayout(this); nav.setPadding(0,dp(8),0,dp(8)); root.addView(nav);
        String[] tabs={"Home","Power","Weather","Internet","Settings"};String[] icons={"⌂","ϟ","☀","◎","⚙"};
        for(int i=0;i<tabs.length;i++){final String item=tabs[i];boolean selected=item.equals(page);LinearLayout cell=column();cell.setGravity(Gravity.CENTER);cell.setPadding(0,dp(8),0,dp(8));View icon=new NavIcon(this,i,selected?green:muted);cell.addView(icon,new LinearLayout.LayoutParams(dp(24),dp(24)));TextView label=text(item.equals("Settings")?"More":item,10,selected?green:muted);label.setGravity(Gravity.CENTER);cell.addView(label);if(selected)cell.setBackground(shape(surface,18));nav.addView(cell,new LinearLayout.LayoutParams(0,-2,1));cell.setOnClickListener(v->go(item));cell.setContentDescription(item);}
        if(motionAllowed()){for(int i=0;i<content.getChildCount();i++){View item=content.getChildAt(i);item.setAlpha(0);item.setTranslationY(dp(10));item.animate().alpha(1).translationY(0).setStartDelay(Math.min(i*20,100)).setDuration(220).start();}}
    }
    private class NavIcon extends View {
        final int type,color;NavIcon(Context c,int t,int col){super(c);type=t;color=col;}
        @Override protected void onDraw(android.graphics.Canvas canvas){super.onDraw(canvas);canvas.save();canvas.scale(getWidth()/24f,getHeight()/24f);android.graphics.Paint p=new android.graphics.Paint(3);p.setColor(color);p.setStyle(android.graphics.Paint.Style.STROKE);p.setStrokeWidth(1.7f);p.setStrokeCap(android.graphics.Paint.Cap.ROUND);p.setStrokeJoin(android.graphics.Paint.Join.ROUND);android.graphics.Path path=new android.graphics.Path();
        if(type==0){path.moveTo(3,11);path.lineTo(12,3);path.lineTo(21,11);path.moveTo(5,10);path.lineTo(5,21);path.lineTo(10,21);path.lineTo(10,15);path.lineTo(14,15);path.lineTo(14,21);path.lineTo(19,21);path.lineTo(19,10);canvas.drawPath(path,p);}
        else if(type==1){path.moveTo(14,2);path.lineTo(5,13);path.lineTo(11,13);path.lineTo(10,22);path.lineTo(19,10);path.lineTo(13,10);path.close();canvas.drawPath(path,p);}
        else if(type==2){canvas.drawCircle(12,12,4,p);for(int j=0;j<8;j++){double a=j*Math.PI/4;canvas.drawLine((float)(12+7*Math.cos(a)),(float)(12+7*Math.sin(a)),(float)(12+10*Math.cos(a)),(float)(12+10*Math.sin(a)),p);}}
        else if(type==3){canvas.drawArc(2,4,22,24,220,100,false,p);canvas.drawArc(6,9,18,21,220,100,false,p);p.setStyle(android.graphics.Paint.Style.FILL);canvas.drawCircle(12,19,1.5f,p);}
        else {for(int y=6;y<=18;y+=6){canvas.drawLine(3,y,21,y,p);p.setStyle(android.graphics.Paint.Style.FILL);canvas.drawCircle(y==12?15:8,y,2.8f,p);p.setStyle(android.graphics.Paint.Style.STROKE);}}canvas.restore();}
    }
    private void home() {
        java.util.Calendar now=java.util.Calendar.getInstance();int hour=now.get(java.util.Calendar.HOUR_OF_DAY);
        note(hour<12?"Good morning":hour<18?"Good afternoon":"Good evening");title("The treehouse");
        note(new java.text.SimpleDateFormat("EEEE, MMMM d",java.util.Locale.getDefault()).format(new Date())+"  ·  Three levels, one place");
        lowBatteryCards();
        LinearLayout hero=card("Energy at a glance", "Your latest entries. Estimates update as equipment changes.");
        LinearLayout powerRow=new LinearLayout(this);powerRow.setGravity(Gravity.CENTER_VERTICAL);hero.addView(powerRow);
        BatteryDial dial=new BatteryDial(this);powerRow.addView(dial,new LinearLayout.LayoutParams(dp(112),dp(126)));
        LinearLayout metrics=column();metrics.setPadding(dp(16),0,0,0);powerRow.addView(metrics,new LinearLayout.LayoutParams(0,-2,1));
        metrics.addView(text(devices.length()==0?"No equipment yet":f(totalWatts())+" W",devices.length()==0?18:30,ink));metrics.addView(text("Active load estimate",12,muted));metrics.addView(text(f(number("input",0))+" W charging input",14,green));
        linkRow(hero,"Manage power & equipment",()->go("Power"));
        LinearLayout row=new LinearLayout(this);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,dp(16),0,0);content.addView(row,rp);
        statTile(row,"Planned energy",f(totalWh()/1000)+" kWh","per day");statTile(row,"Estimated cost","$"+String.format(java.util.Locale.US,"%.2f",totalWh()/1000*number("rate",0.15)),"per day");
        LinearLayout conditions=card("Outside right now",weatherSummary());conditions.setOnClickListener(v->go("Weather"));linkRow(conditions,"Weather & temperature",()->go("Weather"));
        LinearLayout connection=card("Internet",networkSummary());linkRow(connection,"Connection details",()->go("Internet"));
        sectionLabel("YOUR SPACES");
        photoSpace(dev.treehouse.connect.R.drawable.cabin_lounge,"Lower lounge","LEVEL 01 · SEATING & BATTERY FAN",()->go("Power"));
        photoSpace(dev.treehouse.connect.R.drawable.cabin_deck,"Kitchen deck","LEVEL 02 · KITCHEN & BATTERY FAN",()->go("Supplies"));
        spaceRow("03","Chair area","A quiet spot above the deck",()->go("Tasks"));
        coolingCards();
        sectionLabel("KEEP THINGS RUNNING");
        LinearLayout tools=card("Treehouse essentials","");linkRow(tools,"Kitchen & supplies  ·  "+supplies.length()+" items",()->go("Supplies"));linkRow(tools,"Maintenance checklist  ·  "+tasks.length()+" tasks",()->go("Tasks"));linkRow(tools,"Updates  ·  "+unread()+" unread",()->go("Inbox"));
    }
    private void photoSpace(int image,String name,String caption,Runnable action){CabinScene scene=new CabinScene(this,image,name,caption);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(180));p.setMargins(0,dp(14),0,0);content.addView(scene,p);scene.setOnClickListener(v->action.run());scene.setContentDescription(name+". "+caption);}
    private void coolingCards(){
        sectionLabel("FAN COOLING");
        for(int i=1;i<=2;i++){final int level=i;String key="fanBattery"+i;LinearLayout fan=card("Level "+i+" · Battery fan",prefs.contains(key)?"Last entered battery: "+f(number(key,0))+"% · "+stamp(prefs.getLong(key+"Updated",0)):"Battery-powered cooling. Add a reading from your fan.");linkRow(fan,"Update fan battery",()->editFanBattery(level));}
        note("Fans cool Levels 1 and 2. No cooling equipment on Level 3. Fan batteries are separate from the power station.");
    }
    private void editFanBattery(int level){String key="fanBattery"+level;LinearLayout form=column();form.setPadding(dp(20),dp(10),dp(20),dp(10));EditText value=numeric(form,"Fan battery (%)",prefs.getString(key,""));form.addView(text("Enter the fan’s current battery reading. This app cannot read it automatically.",14,muted));AlertDialog d=new AlertDialog.Builder(this).setTitle("Level "+level+" fan battery").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();d.setOnShowListener(v->d.getButton(-1).setOnClickListener(b->{try{double percent=parse(value,0,100);prefs.edit().putString(key,Double.toString(percent)).putLong(key+"Updated",System.currentTimeMillis()).apply();checkLowBatteries();d.dismiss();render();}catch(IllegalArgumentException ignored){}}));d.show();}
    private String[] batteryKeys(){return new String[]{"battery","fanBattery1","fanBattery2"};}
    private String batteryName(String key){return key.equals("battery")?"Power station":key.equals("fanBattery1")?"Level 1 fan":"Level 2 fan";}
    private boolean hasBattery(String key){return key.equals("battery")?prefs.contains("capacity"):prefs.contains(key);}
    private void lowBatteryCards(){if(!prefs.getBoolean("lowBatteryAlerts",true))return;double threshold=number("batteryThreshold",20);for(String key:batteryKeys())if(hasBattery(key)&&number(key,100)<=threshold){LinearLayout warning=card("Low battery · "+batteryName(key),f(number(key,0))+"% last entered · Warning at "+f(threshold)+"% or lower.
Charge it when convenient and update its reading.");GradientDrawable panel=shape(darkMode?0xFF443522:0xFFFFEAD0,20);warning.setBackground(panel);}}
    private void checkLowBatteries(){boolean enabled=prefs.getBoolean("lowBatteryAlerts",true);double threshold=number("batteryThreshold",20);for(String key:batteryKeys()){boolean low=PowerMath.lowBattery(enabled,hasBattery(key),number(key,100),threshold);String latch="warned_"+key;if(PowerMath.shouldWarn(low,prefs.getBoolean(latch,false))){prefs.edit().putBoolean(latch,true).apply();String title="Low battery: "+batteryName(key);String body=f(number(key,0))+"% entered for "+accountName()+". Charge it and update the reading.";try{JSONObject item=new JSONObject();item.put("title",title);item.put("body",body);item.put("time",System.currentTimeMillis());item.put("read",false);inbox.put(item);if(inbox.length()>100)inbox.remove(0);persistInbox();}catch(JSONException ignored){}NotificationManager nm=getSystemService(NotificationManager.class);if(prefs.getBoolean("notifications",true)&&nm.areNotificationsEnabled()){Intent intent=new Intent(this,MainActivity.class).putExtra("openInbox",true).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);PendingIntent tap=PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);nm.notify(100+java.util.Arrays.asList(batteryKeys()).indexOf(key),new Notification.Builder(this,"updates").setSmallIcon(dev.treehouse.connect.R.drawable.ic_tree).setContentTitle(title).setContentText(body).setContentIntent(tap).setAutoCancel(true).build());}}else if(!low){prefs.edit().putBoolean(latch,false).apply();getSystemService(NotificationManager.class).cancel(100+java.util.Arrays.asList(batteryKeys()).indexOf(key));}}}
    private void batteryAlertSettings(){LinearLayout panel=card("Low battery alerts","Checks your saved power-station and fan readings. No live monitoring or background battery prediction. Each battery warns once until its reading rises above the threshold.");Switch toggle=new Switch(this);toggle.setText("Warn about low battery");toggle.setTextColor(ink);toggle.setChecked(prefs.getBoolean("lowBatteryAlerts",true));panel.addView(toggle);toggle.setOnCheckedChangeListener((v,on)->{prefs.edit().putBoolean("lowBatteryAlerts",on).apply();checkLowBatteries();render();});EditText threshold=numeric(panel,"Warn at or below (%)",prefs.getString("batteryThreshold","20"));button(panel,"Save warning threshold",()->{try{double n=parse(threshold,1,100);prefs.edit().putString("batteryThreshold",Double.toString(n)).apply();checkLowBatteries();render();}catch(IllegalArgumentException ignored){}});linkRow(panel,"Allow phone notifications",()->{if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},11);else startActivity(new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE,getPackageName()));});}
    private class CabinScene extends View {
        final android.graphics.Bitmap photo;final String headline,caption;
        CabinScene(Context c,int resource,String h,String cap){super(c);photo=android.graphics.BitmapFactory.decodeResource(getResources(),resource);headline=h;caption=cap;setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(android.graphics.Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();android.graphics.Paint p=new android.graphics.Paint(3);android.graphics.Path mask=new android.graphics.Path();mask.addRoundRect(new android.graphics.RectF(0,0,w,h),dp(24),dp(24),android.graphics.Path.Direction.CW);c.save();c.clipPath(mask);
        // Display the photo portion of the supplied gallery screenshot.
        android.graphics.Rect src=new android.graphics.Rect(0,(int)(photo.getHeight()*.394f),photo.getWidth(),(int)(photo.getHeight()*.607f));float scale=Math.max(w/src.width(),h/src.height());float dw=src.width()*scale,dh=src.height()*scale;c.drawBitmap(photo,src,new android.graphics.RectF((w-dw)/2,(h-dh)/2,(w+dw)/2,(h+dh)/2),p);
        p.setShader(new android.graphics.LinearGradient(0,0,0,h,new int[]{0x090D1710,0xBB0D1710},null,android.graphics.Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);p.setColor(Color.WHITE);p.setTextSize(dp(27));p.setTypeface(Typeface.create("serif",Typeface.NORMAL));c.drawText(headline,dp(20),h-dp(47),p);p.setColor(0xFFE3D8BE);p.setTextSize(dp(9));p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));c.drawText(caption,dp(20),h-dp(24),p);c.restore();}
    }
    private class BatteryDial extends View {
        BatteryDial(Context c){super(c);setContentDescription(prefs.contains("capacity")?f(number("battery",100))+" percent battery, manually entered":"Battery reading not entered");}
        @Override protected void onDraw(android.graphics.Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2,cy=h/2;float radius=Math.min(w,h)/2-dp(8);android.graphics.Paint p=new android.graphics.Paint(3);p.setStyle(android.graphics.Paint.Style.STROKE);p.setStrokeWidth(dp(7));p.setColor(darkMode?0xFF3B4438:0xFFE9E5D8);android.graphics.RectF ring=new android.graphics.RectF(cx-radius,cy-radius,cx+radius,cy+radius);c.drawArc(ring,135,270,false,p);p.setStrokeCap(android.graphics.Paint.Cap.ROUND);p.setColor(green);if(prefs.contains("capacity"))c.drawArc(ring,135,(float)(270*number("battery",100)/100),false,p);p.setStyle(android.graphics.Paint.Style.FILL);p.setTextAlign(android.graphics.Paint.Align.CENTER);p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));p.setTextSize(dp(27));p.setColor(ink);c.drawText(prefs.contains("capacity")?Math.round(number("battery",100))+"%":"—",cx,cy+dp(6),p);p.setTextSize(dp(10));p.setColor(muted);c.drawText("BATTERY",cx,cy+dp(24),p);}
    }
    private void sectionLabel(String label){TextView t=text(label,11,muted);t.setLetterSpacing(.12f);t.setPadding(0,dp(26),0,dp(2));content.addView(t);}
    private void statTile(LinearLayout row,String label,String value,String unit){LinearLayout tile=column();tile.setBackground(shape(surface,20));tile.setPadding(dp(16),dp(16),dp(12),dp(16));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(0,0,dp(8),0);row.addView(tile,p);tile.addView(text(label,12,muted));TextView big=text(value,23,ink);big.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));tile.addView(big);tile.addView(text(unit,12,muted));}
    private void linkRow(LinearLayout parent,String label,Runnable action){TextView row=text(label+"   ›",15,ink);row.setPadding(0,dp(16),0,dp(16));parent.addView(row,new LinearLayout.LayoutParams(-1,-2));row.setOnClickListener(v->action.run());row.setBackgroundResource(android.R.drawable.list_selector_background);}
    private void spaceRow(String number,String name,String detail,Runnable action){LinearLayout c=card(name,detail);TextView badge=text(number,12,green);badge.setLetterSpacing(.1f);c.addView(badge,0);c.setOnClickListener(v->action.run());c.setContentDescription(name+". "+detail);}
    private EditText input(LinearLayout parent,String hint,String value,boolean multiline) {
        EditText e=new EditText(this); e.setHint(hint); e.setText(value); e.setTextColor(ink); e.setHintTextColor(muted); e.setSingleLine(!multiline); e.setInputType(multiline?android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE:android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES); parent.addView(e,new LinearLayout.LayoutParams(-1,-2)); return e;
    }
    private void profile() {
        title("Your profile"); note("Choose how your name appears in the app.");
        String name=prefs.getString("name","Explorer"); LinearLayout identity=card(name.isEmpty()?"Explorer":name,"Local profile • Only visible on this device");
        LinearLayout edit=card("Profile details","");
        EditText n=input(edit,"Display name",name,false); n.setContentDescription("Display name");
        EditText b=input(edit,"Bio",prefs.getString("bio",""),true); b.setContentDescription("Bio");
        button(edit,"Save profile",()->{ String value=n.getText().toString().trim(); if(value.isEmpty()){n.setError("Please enter a name");return;} if(value.length()>60){n.setError("Use 60 characters or fewer");return;} if(b.length()>500){b.setError("Use 500 characters or fewer");return;} prefs.edit().putString("name",value).putString("bio",b.getText().toString().trim()).apply(); Toast.makeText(this,"Profile saved",Toast.LENGTH_SHORT).show(); render(); });
    }
    private int unread() { int n=0; for(int i=0;i<inbox.length();i++) if(!inbox.optJSONObject(i).optBoolean("read"))n++; return n; }
    private void persistInbox() { prefs.edit().putString("inbox",inbox.toString()).apply(); }
    private void notifications() {
        title("Your updates"); note(unread()+" unread • Local notification inbox");
        LinearLayout tools=card("Notifications","Send a test update to your inbox and, when permitted, your Android notification tray."); button(tools,"Send test notification",this::testNotification);
        if(inbox.length()==0) card("All caught up", "No updates yet. Try sending your first test notification.");
        else {
            button(content,"Mark all as read",()->{for(int i=0;i<inbox.length();i++)try{inbox.getJSONObject(i).put("read",true);}catch(JSONException ignored){} persistInbox();render();});
            for(int i=inbox.length()-1;i>=0;i--) { JSONObject item=inbox.optJSONObject(i); LinearLayout c=card((item.optBoolean("read")?"":"●  ")+item.optString("title"),item.optString("body")+"\n"+DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(item.optLong("time")))); c.setOnClickListener(v->{try{item.put("read",true);}catch(JSONException ignored){}persistInbox();render();}); }
            button(content,"Clear inbox",()->new AlertDialog.Builder(this).setTitle("Clear all updates?").setMessage("This removes the local inbox history.").setNegativeButton("Cancel",null).setPositiveButton("Clear",(d,w)->{inbox=new JSONArray();persistInbox();getSystemService(NotificationManager.class).cancelAll();render();}).show());
        }
    }
    private void testNotification() {
        if(!prefs.getBoolean("notifications",true)){Toast.makeText(this,"Enable notifications in Settings first",Toast.LENGTH_LONG).show();return;}
        if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){pendingTest=true;requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},10);return;}
        sendTest();
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results) { super.onRequestPermissionsResult(request,permissions,results); if(request==10 && pendingTest){pendingTest=false;sendTest();} }
    private void sendTest() {
        try { JSONObject item=new JSONObject();item.put("title","Treehouse update");item.put("body","Your local notification inbox is ready.");item.put("time",System.currentTimeMillis());item.put("read",false);inbox.put(item); if(inbox.length()>100) inbox.remove(0);persistInbox(); }catch(JSONException ignored){}
        NotificationManager manager=getSystemService(NotificationManager.class);
        if(manager.areNotificationsEnabled()) {
            Intent intent=new Intent(this,MainActivity.class).putExtra("openInbox",true).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent tap=PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            manager.notify(1,new Notification.Builder(this,"updates").setSmallIcon(dev.treehouse.connect.R.drawable.ic_tree).setContentTitle("Treehouse update").setContentText("Your local notifications are ready.").setContentIntent(tap).setAutoCancel(true).build());
            Toast.makeText(this,"Test notification sent",Toast.LENGTH_SHORT).show();
        }else Toast.makeText(this,"Saved to inbox. Android notifications are blocked in system settings.",Toast.LENGTH_LONG).show();
        render();
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);if(intent.getBooleanExtra("openInbox",false))go("Inbox");}
    private void chooseTheme() {
        String[] themes={"System","Light","Dark"};int selected=java.util.Arrays.asList(themes).indexOf(prefs.getString("theme","Dark"));
        new AlertDialog.Builder(this).setTitle("Choose appearance").setSingleChoiceItems(themes,selected,(d,w)->{prefs.edit().putString("theme",themes[w]).apply();d.dismiss();render();}).setNegativeButton("Cancel",null).show();
    }
    private void settings() {
        title("Your preferences");note("Accounts, appearance and treehouse tools.");
        LinearLayout appearance=card("Appearance", "Current theme: "+prefs.getString("theme","Dark"));linkRow(appearance,"Change theme",this::chooseTheme);
        LinearLayout alerts=card("Notifications","In-app updates and Android test notifications.");Switch toggle=new Switch(this);toggle.setText("Enable notifications");toggle.setTextColor(ink);toggle.setChecked(prefs.getBoolean("notifications",true));toggle.setPadding(0,dp(16),0,dp(16));alerts.addView(toggle);toggle.setOnCheckedChangeListener((v,on)->{prefs.edit().putBoolean("notifications",on).apply();if(!on)getSystemService(NotificationManager.class).cancelAll();});
        linkRow(alerts,"Android notification settings",()->startActivity(new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE,getPackageName())));
        card("About Treehouse", "Treehouse Connect [DEV]\nVersion 0.6.0 • Native Android\nTreehouse utility edition\nPower estimates and logs stay on this device. Weather uses Open-Meteo. No remote device control or hardware pairing is connected.");
        linkRow(content,"Manage local accounts",()->go("Accounts"));
        linkRow(content,"Supplies & kitchen inventory",()->go("Supplies"));
        linkRow(content,"Maintenance checklist",()->go("Tasks"));
        batteryAlertSettings();
        LinearLayout animations=card("Animations", "Gentle screen entrances and button feedback. Device animation settings are respected.");
        Switch reduced=new Switch(this);reduced.setText("Reduce motion");reduced.setTextColor(ink);reduced.setChecked(prefs.getBoolean("reduceMotion",false));animations.addView(reduced);reduced.setOnCheckedChangeListener((v,on)->{prefs.edit().putBoolean("reduceMotion",on).apply();render();});
        linkRow(content,"Edit profile",()->go("Profile"));
        linkRow(content,"Notification inbox",()->go("Inbox"));
        LinearLayout data=card("Your data", "Your profile, equipment, journals, supplies, tasks, settings, and inbox belong to this local account. Reset affects only this account.");
        button(data,"Reset local data",()->new AlertDialog.Builder(this).setTitle("Reset this local account?").setMessage("All data in "+accountName()+" will be deleted. Other local accounts are unaffected.").setNegativeButton("Cancel",null).setPositiveButton("Reset",(d,w)->{accountEpoch++;weatherLoading=false;weatherError="";prefs.edit().clear().apply();supplies=new JSONArray();tasks=new JSONArray();inbox=new JSONArray();devices=new JSONArray();energyLog=new JSONArray();temperatureLog=new JSONArray();weather=new JSONObject();getSystemService(NotificationManager.class).cancelAll();go("Home");}).show());
    }
    private JSONArray readArray(String key) {
        try { return new JSONArray(prefs.getString(key,"[]")); } catch(JSONException e) { return new JSONArray(); }
    }
    private void saveArray(String key,JSONArray data) { prefs.edit().putString(key,data.toString()).apply(); }
    private double number(String key,double fallback) { try { return Double.parseDouble(prefs.getString(key,Double.toString(fallback))); }catch(Exception e){return fallback;} }
    private String f(double n) { return String.format(java.util.Locale.US,"%.1f",n); }
    private String stamp(long time) { return DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(time)); }
    private double totalWatts() { double n=0;for(int i=0;i<devices.length();i++){JSONObject d=devices.optJSONObject(i);if(d.optBoolean("active"))n+=d.optDouble("watts");}return n; }
    private double totalWh() { double n=0;for(int i=0;i<devices.length();i++){JSONObject d=devices.optJSONObject(i);n+=PowerMath.energyWh(d.optDouble("watts"),d.optDouble("hours"));}return n; }
    private String batterySummary() {
        double capacity=number("capacity",0),percent=number("battery",100),eff=number("efficiency",85),load=totalWatts(),incoming=number("input",0);
        String status=f(percent)+"% manually entered • "+f(capacity)+" Wh capacity\n";
        if(load>incoming) return status+"Estimated runtime: "+f(PowerMath.runtimeHours(capacity,percent,eff,load,incoming))+" hours";
        if(incoming>load && percent<100) return status+"Estimated time to full: "+f(PowerMath.chargingHours(capacity,percent,eff,load,incoming))+" hours";
        return status+(percent>=100 && incoming>=load ? "Battery full at entered level; input covers estimated load." : "Input matches load; no estimated net drain.");
    }
    private EditText numeric(LinearLayout parent,String label,String value) {
        parent.addView(text(label,14,muted)); EditText e=input(parent,label,value,false);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);return e;
    }
    private double parse(EditText e,double min,double max) {
        double n;try{n=Double.parseDouble(e.getText().toString().trim());}catch(Exception ex){e.setError("Enter a number");throw new IllegalArgumentException();}
        if(!Double.isFinite(n)||n<min||n>max){e.setError("Enter a value from "+min+" to "+max);throw new IllegalArgumentException();}return n;
    }
    private void power() {
        title("Power & charging");note("Track your station, equipment and daily use.");
        lowBatteryCards();
        card("Power balance",f(number("input",0))+" W in → "+f(totalWatts())+" W active load\n"+(prefs.contains("capacity")?batterySummary():"Set your power station capacity below."));
        LinearLayout station=card("Your power station", "Enter the values from your station’s display or label.");
        EditText capacity=numeric(station,"Capacity (Wh)",prefs.getString("capacity",""));
        EditText battery=numeric(station,"Battery level (%)",prefs.getString("battery","100"));
        EditText incoming=numeric(station,"Charging input (W)",prefs.getString("input","0"));
        EditText efficiency=numeric(station,"Usable / charging efficiency (%)",prefs.getString("efficiency","85"));
        EditText rate=numeric(station,"Electricity rate ($/kWh)",prefs.getString("rate","0.15"));
        button(station,"Save station readings",()->{try{
            double c=parse(capacity,1,1000000),b=parse(battery,0,100),in=parse(incoming,0,100000),ef=parse(efficiency,1,100),r=parse(rate,0,100);
            prefs.edit().putString("capacity",Double.toString(c)).putString("battery",Double.toString(b)).putString("input",Double.toString(in)).putString("efficiency",Double.toString(ef)).putString("rate",Double.toString(r)).putLong("powerUpdated",System.currentTimeMillis()).apply();checkLowBatteries();render();
        }catch(IllegalArgumentException ignored){}});
        if(prefs.contains("powerUpdated")) note("Readings saved "+stamp(prefs.getLong("powerUpdated",0))+". Update them when conditions change.");
        note("Runtime assumes constant load/input. Charging slows near full. The 85% efficiency and $0.15 rate are editable starting assumptions.");
        coolingCards();
        LinearLayout equipment=card("Equipment",devices.length()+" devices • "+f(totalWh())+" Wh planned per day");button(equipment,"Add equipment",()->editDevice(-1));
        for(int i=0;i<devices.length();i++) {
            final int index=i;JSONObject d=devices.optJSONObject(i);LinearLayout c=card(d.optString("name"),d.optString("zone")+" • "+f(d.optDouble("watts"))+" W • "+f(d.optDouble("hours"))+" h/day\n"+f(PowerMath.energyWh(d.optDouble("watts"),d.optDouble("hours")))+" Wh/day planned");
            Switch active=new Switch(this);active.setText("Include in active load estimate");active.setTextColor(ink);active.setChecked(d.optBoolean("active"));c.addView(active);active.setOnCheckedChangeListener((v,on)->{try{d.put("active",on);}catch(JSONException ignored){}saveArray("devices",devices);render();});
            button(c,"Edit equipment",()->editDevice(index));
            button(c,"Remove equipment",()->new AlertDialog.Builder(this).setTitle("Remove "+d.optString("name")+"?").setNegativeButton("Cancel",null).setPositiveButton("Remove",(dialog,which)->{devices.remove(index);saveArray("devices",devices);render();}).show());
        }
        LinearLayout log=card("Energy journal", "Record meter readings or estimates. Entries keep their source label.");button(log,"Log energy usage",this::logEnergy);
        double sum=0;for(int i=0;i<energyLog.length();i++)sum+=energyLog.optJSONObject(i).optDouble("wh");log.addView(text("Journal total: "+f(sum)+" Wh across "+energyLog.length()+" entries",15,ink));
        for(int i=energyLog.length()-1;i>=Math.max(0,energyLog.length()-10);i--){JSONObject e=energyLog.optJSONObject(i);log.addView(text(f(e.optDouble("wh"))+" Wh • "+e.optString("source")+"\n"+stamp(e.optLong("time"))+" • "+e.optString("note"),14,muted));}
        if(energyLog.length()>0) button(log,"Clear energy journal",()->new AlertDialog.Builder(this).setTitle("Clear energy journal?").setNegativeButton("Cancel",null).setPositiveButton("Clear",(d,w)->{energyLog=new JSONArray();saveArray("energyLog",energyLog);render();}).show());
    }
    private void editDevice(int index) {
        JSONObject d=index<0?new JSONObject():devices.optJSONObject(index);
        LinearLayout form=column();form.setPadding(dp(20),dp(8),dp(20),dp(8));
        EditText name=input(form,"Device name (e.g. deck lights)",d.optString("name"),false);
        EditText watts=numeric(form,"Device wattage (W)",index<0?"":Double.toString(d.optDouble("watts")));
        EditText hours=numeric(form,"Planned hours per day",index<0?"":Double.toString(d.optDouble("hours")));
        Spinner zone=new Spinner(this);String[] zones=levels;zone.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,zones));zone.setSelection(Math.max(0,java.util.Arrays.asList(zones).indexOf(d.optString("zone"))));form.addView(zone);
        ScrollView sc=new ScrollView(this);sc.addView(form);AlertDialog dialog=new AlertDialog.Builder(this).setTitle(index<0?"Add equipment":"Edit equipment").setView(sc).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();
        dialog.setOnShowListener(v->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(button->{try{
            String n=name.getText().toString().trim();if(n.isEmpty()||n.length()>60){name.setError("Enter a name up to 60 characters");return;}
            double w=parse(watts,0,100000),h=parse(hours,0,24);JSONObject item=new JSONObject();item.put("name",n);item.put("watts",w);item.put("hours",h);item.put("zone",zone.getSelectedItem().toString());item.put("active",index<0||d.optBoolean("active"));
            if(index<0)devices.put(item);else devices.put(index,item);saveArray("devices",devices);dialog.dismiss();render();
        }catch(IllegalArgumentException|JSONException ignored){}}));dialog.show();
    }
    private void logEnergy() {
        LinearLayout form=column();form.setPadding(dp(20),0,dp(20),0);EditText wh=numeric(form,"Energy used (Wh)","");EditText note=input(form,"Period / notes (e.g. Thursday evening)","",false);
        Spinner source=new Spinner(this);source.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Manual meter reading","Estimate"}));form.addView(source);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Log energy usage").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();dialog.setOnShowListener(v->dialog.getButton(-1).setOnClickListener(button->{try{double value=parse(wh,0,100000000);JSONObject item=new JSONObject();item.put("wh",value);item.put("note",note.getText().toString());item.put("source",source.getSelectedItem().toString());item.put("time",System.currentTimeMillis());energyLog.put(item);saveArray("energyLog",energyLog);dialog.dismiss();render();}catch(IllegalArgumentException|JSONException ignored){}}));dialog.show();
    }
    private String weatherSummary() {
        JSONObject current=weather.optJSONObject("current");if(current==null)return "No weather loaded. Choose a town and refresh.\nOutdoor weather is separate from treehouse readings.";
        return weather.optString("place")+" • "+f(current.optDouble("temperature_2m"))+"°F\n"+weatherCode(current.optInt("weather_code"))+" • Wind "+f(current.optDouble("wind_speed_10m"))+" mph\n"+"Fetched "+stamp(weather.optLong("fetched"))+" (cached until refreshed)";
    }
    private String weatherCode(int c) { if(c==0)return "Clear";if(c<=3)return "Cloudy / partly cloudy";if(c<=48)return "Fog";if(c<=67)return "Rain / drizzle";if(c<=77)return "Snow";if(c<=82)return "Rain showers";if(c<=86)return "Snow showers";return "Thunderstorms"; }
    private void weatherPage() {
        title("Weather & climate");note("OUTDOOR FORECAST   +   YOUR TREEHOUSE READINGS");
        LinearLayout outside=card("Outside",weatherSummary());JSONObject current=weather.optJSONObject("current");if(current!=null)outside.addView(text("Humidity "+current.optInt("relative_humidity_2m")+"% • Feels like "+f(current.optDouble("apparent_temperature"))+"°F\nModel timestamp: "+current.optString("time"),14,muted));
        LinearLayout location=card("Weather location", "Search a town, optionally followed by its two-letter country code (e.g. Cornelius, US). If results are ambiguous, choose your location.");EditText town=input(location,"Town, country",prefs.getString("town","Cornelius, US"),false);
        button(location,weatherLoading?"Loading weather…":"Refresh weather",()->{if(!weatherLoading){String q=town.getText().toString().trim();if(q.length()<2||q.length()>100){town.setError("Enter a town name (2–100 characters)");return;}fetchWeather(q);}});
        if(!weatherError.isEmpty())note(weatherError);
        note("Weather: Open-Meteo • https://open-meteo.com • Outdoor model data, not a treehouse sensor. Refresh sends the entered town / selected town coordinates to Open-Meteo. No GPS permission is used.");
        LinearLayout inside=card("Treehouse temperature", "Record your thermometer’s reading. Nothing is measured automatically.");button(inside,"Log temperature",this::logTemperature);
        for(int i=temperatureLog.length()-1;i>=Math.max(0,temperatureLog.length()-10);i--){JSONObject t=temperatureLog.optJSONObject(i);inside.addView(text(f(t.optDouble("fahrenheit"))+"°F • "+t.optString("zone")+"\nManual reading • "+stamp(t.optLong("time")),15,ink));}
        if(temperatureLog.length()==0)inside.addView(text("No readings recorded yet.",15,muted));
        if(temperatureLog.length()>0)button(inside,"Clear temperature history",()->new AlertDialog.Builder(this).setTitle("Clear temperature history?").setNegativeButton("Cancel",null).setPositiveButton("Clear",(d,w)->{temperatureLog=new JSONArray();saveArray("temperatureLog",temperatureLog);render();}).show());
    }
    private JSONObject jsonGet(String address) throws Exception {
        javax.net.ssl.HttpsURLConnection c=(javax.net.ssl.HttpsURLConnection)new java.net.URL(address).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(12000);
        try{if(c.getResponseCode()!=200)throw new java.io.IOException("Service unavailable");try(java.io.InputStream in=c.getInputStream();java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))!=-1){out.write(buffer,0,n);if(out.size()>1000000)throw new java.io.IOException("Response too large");}return new JSONObject(out.toString("UTF-8"));}}finally{c.disconnect();}
    }
    private void fetchWeather(String query) {
        final int requestEpoch=accountEpoch;weatherLoading=true;weatherError="";prefs.edit().putString("town",query).apply();render();
        worker.execute(()->{try{
            String[] parts=query.split(",",2);String country=parts.length>1?parts[1].trim():"";String filter=country.matches("[A-Za-z]{2}")?"&countryCode="+country.toUpperCase(java.util.Locale.US):"";
            JSONObject result=jsonGet("https://geocoding-api.open-meteo.com/v1/search?name="+java.net.URLEncoder.encode(parts[0].trim(),"UTF-8")+"&count=5&language=en&format=json"+filter);
            JSONArray places=result.optJSONArray("results");if(places==null||places.length()==0)throw new java.io.IOException("Town not found");
            runOnUiThread(()->{if(isDestroyed()||requestEpoch!=accountEpoch)return;if(places.length()==1)loadForecast(places.optJSONObject(0),requestEpoch);else{
                String[] labels=new String[places.length()];for(int i=0;i<labels.length;i++){JSONObject p=places.optJSONObject(i);labels[i]=p.optString("name")+", "+p.optString("admin1")+", "+p.optString("country");}
                new AlertDialog.Builder(this).setTitle("Choose weather location").setItems(labels,(dialog,index)->loadForecast(places.optJSONObject(index),requestEpoch)).setNegativeButton("Cancel",(d,w)->{weatherLoading=false;render();}).setOnCancelListener(d->{weatherLoading=false;render();}).show();
            }});
        }catch(Exception e){weatherFailure(requestEpoch,"Couldn’t load weather. Check your connection and town name, then try again. Existing cached weather is unchanged.");}});
    }
    private void loadForecast(JSONObject place,int requestEpoch) {
        worker.execute(()->{try{JSONObject result=jsonGet("https://api.open-meteo.com/v1/forecast?latitude="+place.getDouble("latitude")+"&longitude="+place.getDouble("longitude")+"&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&temperature_unit=fahrenheit&wind_speed_unit=mph&timezone=auto");
            JSONObject cur=result.getJSONObject("current");if(!cur.has("temperature_2m")||cur.isNull("temperature_2m"))throw new java.io.IOException("Missing temperature");
            result.put("place",place.optString("name")+", "+place.optString("admin1")+", "+place.optString("country"));result.put("fetched",System.currentTimeMillis());
            runOnUiThread(()->{if(isDestroyed()||requestEpoch!=accountEpoch)return;weather=result;weatherLoading=false;weatherError="";prefs.edit().putString("weather",result.toString()).apply();render();});
        }catch(Exception e){weatherFailure(requestEpoch,"Weather service unavailable. Try again later. Existing cached weather is unchanged.");}});
    }
    private void weatherFailure(int requestEpoch,String message){runOnUiThread(()->{if(isDestroyed()||requestEpoch!=accountEpoch)return;weatherLoading=false;weatherError=message;render();});}
    private void logTemperature(){
        LinearLayout form=column();form.setPadding(dp(20),0,dp(20),0);EditText temp=numeric(form,"Temperature (°F)","");Spinner zone=new Spinner(this);zone.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{levels[0],levels[1],levels[2],"Outside"}));form.addView(zone);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Manual thermometer reading").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();dialog.setOnShowListener(v->dialog.getButton(-1).setOnClickListener(button->{try{double value=parse(temp,-100,160);JSONObject item=new JSONObject();item.put("fahrenheit",value);item.put("zone",zone.getSelectedItem().toString());item.put("time",System.currentTimeMillis());temperatureLog.put(item);saveArray("temperatureLog",temperatureLog);dialog.dismiss();render();}catch(IllegalArgumentException|JSONException ignored){}}));dialog.show();
    }
    private String networkSummary(){
        android.net.ConnectivityManager cm=getSystemService(android.net.ConnectivityManager.class);android.net.NetworkCapabilities c=cm.getNetworkCapabilities(cm.getActiveNetwork());
        if(c==null)return "No active connection detected on this phone.";
        String type=c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)?"Wi-Fi":c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR)?"Cellular":c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET)?"Ethernet":"Other network";
        if(c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_VPN))type+=" / VPN";
        return type+" • "+(c.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)?"Android reports internet available":"Internet not validated by Android")+"\n"+(cm.isActiveNetworkMetered()?"Metered connection":"Unmetered connection")+"\nChecked "+stamp(System.currentTimeMillis());
    }
    private void internet(){
        title("Internet connection");note("THIS PHONE’S CONNECTION   •   NOT A REMOTE TREEHOUSE SENSOR");
        LinearLayout live=card("Network status",networkSummary());button(live,"Refresh connection status",this::render);
        button(live,"Open Wi-Fi settings",()->startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)));
        LinearLayout record=card("Treehouse internet notes", "Keep your provider, router name, and last speed-test result here. Don’t enter passwords.");
        EditText provider=input(record,"Provider / router",prefs.getString("provider",""),false);
        EditText down=numeric(record,"Last measured download (Mbps)",prefs.getString("download",""));
        EditText up=numeric(record,"Last measured upload (Mbps)",prefs.getString("upload",""));
        EditText notes=input(record,"Connection notes",prefs.getString("networkNotes",""),true);
        button(record,"Save internet notes",()->{try{
            String d=down.getText().toString().trim(),u=up.getText().toString().trim();if(!d.isEmpty())parse(down,0,100000);if(!u.isEmpty())parse(up,0,100000);
            prefs.edit().putString("provider",provider.getText().toString()).putString("download",d).putString("upload",u).putString("networkNotes",notes.getText().toString()).putLong("networkUpdated",System.currentTimeMillis()).apply();Toast.makeText(this,"Internet notes saved",Toast.LENGTH_SHORT).show();render();
        }catch(IllegalArgumentException ignored){}});
        if(prefs.contains("networkUpdated"))note("Manual notes updated "+stamp(prefs.getLong("networkUpdated",0)));
        note("Speed values are manual records, not an automatic speed test. Connection status describes this phone wherever it is located.");
    }

    private boolean motionAllowed(){
        return !prefs.getBoolean("reduceMotion",false) && android.provider.Settings.Global.getFloat(getContentResolver(),android.provider.Settings.Global.ANIMATOR_DURATION_SCALE,1f)>0;
    }
    private void saveAccounts(){registry.edit().putString("accounts",accounts.toString()).apply();}
    private String accountName(){for(int i=0;i<accounts.length();i++){JSONObject a=accounts.optJSONObject(i);if(a.optString("id").equals(activeAccount))return a.optString("name");}return "Local account";}
    private void activateAccount(String id){
        accountEpoch++;weatherLoading=false;weatherError="";pendingTest=false;activeAccount=id;registry.edit().putString("active",id).apply();
        prefs=getSharedPreferences(id.equals("default")?"treehouse":"treehouse_"+id,MODE_PRIVATE);
        inbox=readArray("inbox");devices=readArray("devices");energyLog=readArray("energyLog");temperatureLog=readArray("temperatureLog");supplies=readArray("supplies");tasks=readArray("tasks");
        try{weather=new JSONObject(prefs.getString("weather","{}"));}catch(JSONException ignored){weather=new JSONObject();}
        getSystemService(NotificationManager.class).cancelAll();migrateLevels();go("Home");
    }
    private void migrateLevels(){
        for(JSONArray a:new JSONArray[]{devices,temperatureLog})for(int i=0;i<a.length();i++){JSONObject entry=a.optJSONObject(i);String old=entry.optString("zone");try{if(old.equals("Upper deck"))entry.put("zone",levels[1]);else if(old.equals("Lower lounge"))entry.put("zone",levels[0]);else if(old.equals("Both levels"))entry.put("zone",levels[3]);}catch(JSONException ignored){}}
        saveArray("devices",devices);saveArray("temperatureLog",temperatureLog);
    }
    private void accountPage(){
        title("Your accounts");note("LOCAL TO THIS PHONE   •   NO PASSWORD OR CLOUD SIGN-IN");
        LinearLayout intro=card("Separate spaces", "Each account has its own equipment, station settings, weather, journals, supplies, checklist, theme, profile, and inbox. These are local profiles, not secure private logins; anyone using this app can switch between them.");button(intro,"Create local account",()->editAccount(-1));
        for(int i=0;i<accounts.length();i++){
            final int index=i;JSONObject a=accounts.optJSONObject(i);String id=a.optString("id");boolean current=id.equals(activeAccount);
            LinearLayout c=card(a.optString("name")+(current?" • Active":""),current?"You’re using this account.":"Saved on this phone.");
            if(!current)button(c,"Switch to this account",()->activateAccount(id));
            button(c,"Rename account",()->editAccount(index));
            if(accounts.length()>1)button(c,"Delete account",()->new AlertDialog.Builder(this).setTitle("Delete "+a.optString("name")+"?").setMessage("All data in this local account will be removed from this phone. Other accounts are unaffected.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(dialog,w)->{
                getSharedPreferences(id.equals("default")?"treehouse":"treehouse_"+id,MODE_PRIVATE).edit().clear().apply();accounts.remove(index);saveAccounts();if(current)activateAccount(accounts.optJSONObject(0).optString("id"));else render();
            }).show());
        }
    }
    private void editAccount(int index){
        LinearLayout form=column();form.setPadding(dp(20),0,dp(20),0);EditText name=input(form,"Account name",index<0?"":accounts.optJSONObject(index).optString("name"),false);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(index<0?"Create local account":"Rename account").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();d.setOnShowListener(v->d.getButton(-1).setOnClickListener(b->{
            String n=name.getText().toString().trim();if(n.isEmpty()||n.length()>40){name.setError("Use 1–40 characters");return;}
            for(int i=0;i<accounts.length();i++)if(i!=index&&accounts.optJSONObject(i).optString("name").equalsIgnoreCase(n)){name.setError("That account name already exists");return;}
            try{if(index<0){JSONObject a=new JSONObject();String id=java.util.UUID.randomUUID().toString();a.put("id",id);a.put("name",n);accounts.put(a);saveAccounts();getSharedPreferences("treehouse_"+id,MODE_PRIVATE).edit().putString("name",n).apply();d.dismiss();activateAccount(id);}else{accounts.getJSONObject(index).put("name",n);saveAccounts();d.dismiss();render();}}catch(JSONException ignored){}
        }));d.show();
    }
    private int completedTasks(){int n=0;for(int i=0;i<tasks.length();i++)if(tasks.optJSONObject(i).optBoolean("done"))n++;return n;}
    private void suppliesPage(){
        title("Supplies & kitchen");note("YOUR TREEHOUSE INVENTORY   •   "+accountName());
        LinearLayout intro=card("Keep the essentials ready",supplies.length()+" items recorded. Add food, cooking equipment, lights, batteries, and other supplies.");button(intro,"Add inventory item",()->editEntry(false,-1));
        if(supplies.length()==0)card("A fresh inventory", "Add your first item to get started. Nothing is prefilled.");
        for(int i=0;i<supplies.length();i++){final int index=i;JSONObject item=supplies.optJSONObject(i);LinearLayout c=card(item.optString("name"),"Quantity: "+item.optInt("quantity")+" • "+item.optString("zone")+"\n"+item.optString("detail"));button(c,"Edit item",()->editEntry(false,index));button(c,"Remove item",()->removeEntry(false,index));}
    }
    private void tasksPage(){
        title("Care for your space");note("MAINTENANCE CHECKLIST   •   "+accountName());
        LinearLayout intro=card("One thing at a time",completedTasks()+" of "+tasks.length()+" tasks complete. Record cleaning, equipment checks, kitchen restocking, and other jobs.");button(intro,"Add a task",()->editEntry(true,-1));
        if(tasks.length()==0)card("Ready when you are", "Add a task and check it off when it’s finished.");
        for(int i=0;i<tasks.length();i++){final int index=i;JSONObject item=tasks.optJSONObject(i);LinearLayout c=card(item.optString("name"),item.optString("zone")+"\n"+item.optString("detail"));CheckBox done=new CheckBox(this);done.setText("Completed");done.setTextColor(ink);done.setChecked(item.optBoolean("done"));c.addView(done);done.setOnCheckedChangeListener((v,on)->{try{item.put("done",on);}catch(JSONException ignored){}saveArray("tasks",tasks);render();});button(c,"Edit task",()->editEntry(true,index));button(c,"Remove task",()->removeEntry(true,index));}
    }
    private void removeEntry(boolean task,int index){
        JSONArray list=task?tasks:supplies;new AlertDialog.Builder(this).setTitle("Remove "+list.optJSONObject(index).optString("name")+"?").setNegativeButton("Cancel",null).setPositiveButton("Remove",(d,w)->{list.remove(index);saveArray(task?"tasks":"supplies",list);render();}).show();
    }
    private void editEntry(boolean task,int index){
        JSONArray list=task?tasks:supplies;JSONObject previous=index<0?new JSONObject():list.optJSONObject(index);
        LinearLayout form=column();form.setPadding(dp(20),dp(8),dp(20),dp(8));EditText name=input(form,task?"Task name":"Item name",previous.optString("name"),false);
        EditText quantity=task?null:numeric(form,"Quantity",index<0?"1":Integer.toString(previous.optInt("quantity")));
        EditText detail=input(form,task?"Notes / target date (optional)":"Notes / unit (optional)",previous.optString("detail"),true);
        form.addView(text("Location",14,muted));Spinner zone=new Spinner(this);zone.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,levels));zone.setSelection(index<0?1:Math.max(0,java.util.Arrays.asList(levels).indexOf(previous.optString("zone"))));form.addView(zone);
        ScrollView scroll=new ScrollView(this);scroll.addView(form);AlertDialog d=new AlertDialog.Builder(this).setTitle(task?"Maintenance task":"Inventory item").setView(scroll).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();d.setOnShowListener(v->d.getButton(-1).setOnClickListener(b->{try{
            String n=name.getText().toString().trim();if(n.isEmpty()||n.length()>80){name.setError("Use 1–80 characters");return;}double q=task?0:parse(quantity,0,1000000);if(!task&&q!=Math.floor(q)){quantity.setError("Enter a whole number");return;}
            JSONObject item=new JSONObject();item.put("name",n);item.put("zone",zone.getSelectedItem().toString());item.put("detail",detail.getText().toString());item.put("quantity",(int)q);item.put("done",previous.optBoolean("done"));if(index<0)list.put(item);else list.put(index,item);saveArray(task?"tasks":"supplies",list);d.dismiss();render();
        }catch(IllegalArgumentException|JSONException ignored){}}));d.show();
    }

}
